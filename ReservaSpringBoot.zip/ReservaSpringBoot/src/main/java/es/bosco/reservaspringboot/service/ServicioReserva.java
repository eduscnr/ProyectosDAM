package es.bosco.reservaspringboot.service;

import es.bosco.reservaspringboot.Reserva;
import es.bosco.reservaspringboot.repositorie.ReservaDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioReserva {
    @Autowired
    ReservaDAO reservaDAO;
    public boolean insertarActualizarReserva(Reserva r){
        try{
            reservaDAO.save(r);
            return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
    public List<Reserva> getAllReservas(){
        return reservaDAO.findAll();
    }

    public Reserva getReserva(long id){
        try{
            return reservaDAO.getReferenceById(id);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    public boolean eliminarReserva(long id){
        try{
            reservaDAO.deleteById(id);
            return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
}
