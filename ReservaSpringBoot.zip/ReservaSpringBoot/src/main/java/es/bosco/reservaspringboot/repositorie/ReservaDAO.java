package es.bosco.reservaspringboot.repositorie;

import es.bosco.reservaspringboot.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ReservaDAO extends JpaRepository<Reserva, Long> {
    //Consultas via QUERY
    @Query("select r from Reserva r where r.procedencia = :p and r.destino = :d")
    public List seleccionarReservarProDes(String p, String d);
    //Consultas via nombres inclusivo
    public List findReservasByProcedenciaAndDestino(String procedencia, String destino);

}