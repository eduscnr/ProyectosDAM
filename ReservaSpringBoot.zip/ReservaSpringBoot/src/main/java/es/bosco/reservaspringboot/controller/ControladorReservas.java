package es.bosco.reservaspringboot.controller;

import es.bosco.reservaspringboot.Reserva;
import es.bosco.reservaspringboot.service.ServicioReserva;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ControladorReservas {
    @Autowired
    Reserva reserva;  //EN VEZ DE  = new Reserva();
    @Autowired
    ServicioReserva servicioReserva;   //EN VEZ DE   =new ReservaDAOImpl("BAU1");

    String usuario;
    String rol;

    @RequestMapping("/")
    public String inicio(Model session) {
        // Obtener la autenticación actual
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        //Obtener usuario y roles
        usuario = authentication.getName();
        List roles = (List) authentication.getAuthorities();
        rol = roles.get(0).toString();
        System.out.println(rol);
        //Establecer dos atributos en la sesion
        session.addAttribute("elUsuario", usuario);
        session.addAttribute("elRol", rol);
        return "index";
    }
    @PreAuthorize("hasRole('ROLE_USER')")
    @RequestMapping("/saludo")
    public String procesarSaludoPersonalizado(Model model) {
        String saludo = "Saludos " + (usuario != null && !usuario.isEmpty() ? usuario + " -- "+ rol : "Invitado") + " desde Spring MVC";
        model.addAttribute("mensajeSaludo", saludo);
        return "saludoPersonalizado"; //JSP
    }

    //*******************************************************************************
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping("/agregarReserva")
    public String agregarReserva(Model modelo) {
        modelo.addAttribute("laReserva", reserva);
        if (usuario.equals("admin"))
            return "formularioAgregar"; //JSP
        else return "redirect:/login";
    }


    @PostMapping("/agregarReserva")
    public String procesarAgregarReserva(@ModelAttribute("laReserva") @Valid Reserva reserva, BindingResult result) {
        if (!result.hasErrors()) {  //Si no hay errores, se procesa debidamente
            if (servicioReserva.insertarActualizarReserva(reserva)) {
                return "redirect:/verReservas";   // url al Controlador

            } else {
                //  lanzamos una excepción
                throw new RuntimeException("Error al guardar la reserva");
            }
        } else {  //Si hay errores vamos de nuevo al formulario
            return "formularioAgregar"; //JSP
        }
    }


    //*******************************************************************************
    @GetMapping("/verReservas")
    public String mostrarReservas(Model modelo) {
        List<Reserva> reservas = servicioReserva.getAllReservas();
        modelo.addAttribute("lasReservas", reservas);
        modelo.addAttribute("elRol", rol);
        modelo.addAttribute("elUsuario", usuario);
        return "tablaReservas";  //JSP
    }

    //*******************************************************************************
    @Secured({"ROLE_ADMIN", "ROLE_USER"})
    @GetMapping("/editar/{idR}")
    public String mostrarFormularioEditar(@PathVariable("idR") long idRerserva, Model model) {
        // Obtener la reserva por su ID
        Reserva reserva = servicioReserva.getReserva(idRerserva);
        if (reserva != null) {
            model.addAttribute("laReserva", reserva);   //vehículo de transporte
            return "formularioEdicion";  //JSP
        } else {
            //  lanzamos una excepción
            throw new RuntimeException("Error en la edicion de la reserva");
        }
    }

    @PostMapping("/editar")
    public String procesarEditarReserva(@ModelAttribute("laReserva") Reserva reserva) {
        // Lógica para editar la reserva
        if (servicioReserva.insertarActualizarReserva(reserva)) {
            return "redirect:verReservas";   // url al Controlador
        } else {
            //  lanzamos una excepción
            throw new RuntimeException("Error al editar  la reserva");
        }
    }

    //*******************************************************************************
    @GetMapping("/eliminar/{idR}")
    public String eliminarReserva(@PathVariable long idR) {
        // Lógica para eliminar la reserva

        if (servicioReserva.eliminarReserva(idR)) {
            return "redirect:/verReservas";   // url al Controlador
        } else {
            //  lanzamos una excepción
            throw new RuntimeException("Error al eliminar la reserva");
        }
    }

}
