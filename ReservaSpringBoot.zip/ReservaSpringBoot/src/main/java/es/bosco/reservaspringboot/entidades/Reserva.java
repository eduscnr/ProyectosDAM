package es.bosco.reservaspringboot;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component  //Spring
@Entity     //JPA
@Table(name="RESERVAS")
@Scope("singleton")  //@Scope("prototype")
public class Reserva {
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "miSecuencia")
    @SequenceGenerator(name = "miSecuencia", sequenceName = "DAM2_SEQ_RESERVA", allocationSize = 1)
    @Id
    private long idR;

    @NotEmpty
    @Size(max = 20)
    @Pattern(regexp = "^[a-zA-ZñÑáéíóúÁÉÍÓÚ\\s]+$")
    private String nombre;

    @NotEmpty
    @Size(max = 40)
    private String apellidos;

    private String sexo;
    private String comidas;
    private String procedencia;
    private String destino;

    //getters y setters,


    public Reserva() {
    }

    public Reserva(long idR, String nombre, String apellidos, String sexo, String comidas, String procedencia, String destino) {
        this.idR = idR;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.sexo = sexo;
        this.comidas = comidas;
        this.procedencia = procedencia;
        this.destino = destino;
    }

    public long getIdR() {
        return idR;
    }

    public void setIdR(long idR) {
        this.idR = idR;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getComidas() {
        return comidas;
    }

    public void setComidas(String comidas) {
        this.comidas = comidas;
    }

    public String getProcedencia() {
        return procedencia;
    }

    public void setProcedencia(String procedencia) {
        this.procedencia = procedencia;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "Reserva{" +
                "idR=" + idR +
                ", nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", sexo='" + sexo + '\'' +
                ", comidas='" + comidas + '\'' +
                ", procedencia='" + procedencia + '\'' +
                ", destino='" + destino + '\'' +
                '}';
    }
}