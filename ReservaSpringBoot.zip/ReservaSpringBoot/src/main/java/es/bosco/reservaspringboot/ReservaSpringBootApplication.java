package es.bosco.reservaspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservaSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReservaSpringBootApplication.class, args);
    }

}
