package com.example.notificaciones;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permission is granted. Continue the action or workflow in your
                    // app.
                } else {
                    // Explain to the user that the feature is unavailable because the
                    // feature requires a permission that the user has denied. At the
                    // same time, respect the user's decision. Don't link to system
                    // settings in an effort to convince the user to change their
                    // decision.
                    System.out.println("Denagado");
                }
            });
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED) {
            int notifId=1; //Identificador de la notificación, para futuras modificaciones.
            NotificationCompat.Builder constructorNotif = new NotificationCompat.Builder(this,"mi_canal");
            constructorNotif.setSmallIcon(android.R.drawable.ic_dialog_alert);
            constructorNotif.setContentTitle("Mi notificación");
            constructorNotif.setContentText("Has recibido una notificación!!");
            NotificationManager notificador =
                    (NotificationManager)
                            getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
            //A partir de la version O, hay que crear un canal de notificación
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                System.out.println("Entro");
                NotificationChannel channel = new NotificationChannel("mi_canal",
                        "título del canal de notificación",
                        NotificationManager.IMPORTANCE_DEFAULT);
                notificador.createNotificationChannel(channel);
            }
            notificador.notify(notifId, constructorNotif.build());
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(
                this, android.Manifest.permission.POST_NOTIFICATIONS)) {
            // In an educational UI, explain to the user why your app requires this
            // permission for a specific feature to behave as expected, and what
            // features are disabled if it's declined. In this UI, include a
            // "cancel" or "no thanks" button that lets the user continue
            // using your app without granting the permission.
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
        } else {
            // You can directly ask for the permission.
            // The registered ActivityResultCallback gets the result of this request.
            requestPermissionLauncher.launch(
                    Manifest.permission.POST_NOTIFICATIONS);
        }
    }
}