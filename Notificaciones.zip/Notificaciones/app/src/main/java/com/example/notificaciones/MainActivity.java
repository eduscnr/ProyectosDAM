package com.example.notificaciones;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    showNotification();
                } else {
                    System.out.println("Denegado");
                    Toast.makeText(this, "Si no aceptar el permiso deberia de aceptar", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkNotificationPermission();
    }

    private void checkNotificationPermission() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECEIVE_BOOT_COMPLETED) ==
                PackageManager.PERMISSION_GRANTED) {
            showNotification();
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(
                this, Manifest.permission.RECEIVE_BOOT_COMPLETED)) {
            requestPermissionLauncher.launch(Manifest.permission.RECEIVE_BOOT_COMPLETED);
        } else {
            requestPermissionLauncher.launch(Manifest.permission.RECEIVE_BOOT_COMPLETED);
        }
    }

    private void showNotification() {
        int notifId = 1;
        NotificationCompat.Builder constructorNotif = new NotificationCompat.Builder(this, "mi_canal");
        constructorNotif.setSmallIcon(android.R.drawable.ic_dialog_alert);
        constructorNotif.setContentTitle("Mi notificación");
        constructorNotif.setContentText("Has recibido una notificación!!");
        NotificationManager notificador = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // A partir de la versión O, hay que crear un canal de notificación
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("mi_canal",
                    "título del canal de notificación",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificador.createNotificationChannel(channel);
        }

        notificador.notify(notifId, constructorNotif.build());
    }
}
