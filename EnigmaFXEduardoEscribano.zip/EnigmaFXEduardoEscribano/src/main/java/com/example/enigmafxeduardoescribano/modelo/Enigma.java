package com.example.enigmafxeduardoescribano.modelo;

public class Enigma {
    //Yo cambiar por a=frente, b= frete, c = tapa
    private int a;
    private int b;
    private int c;
    private int v;

    private boolean comprobar;
    private String mayor;
    // Constructor parametrizado
    public Enigma(int x, int y, int z){
        a=x;
        b=y;
        c=z;
        v=queHace();
        comprobar = comprobar();
        mayor = mayor();
    }

    // Constructor sin parametros
    public Enigma(){
        a=10;
        b=10;
        c=10;
        v=1000;
        comprobar = comprobar();
        mayor = mayor();
    }

    public int getA(){
        return a;
    }
    public int getB(){
        return b;
    }
    public int getC(){
        return c;
    }
    public int getV(){
        return v;
    }

    public boolean isComprobar() {
        return comprobar;
    }

    public String getMayor() {
        return mayor;
    }

    public boolean comprobar(){
        // De momento siempre devuelve true.
        // Debe devolver true si a=b=c
        // o false en otro caso
        if(a==b && a==c && b ==c){
            return true;
        }
        return false;
    }
    public String mayor(){
        // De momento devuelve "Ninguno"
        // Debe comparar y devolver una string con
        // indicacion de cual es el mayor de los productos
        // "(a*b)" o "(b*c)" o "(a*c)"
        if(getAB()>getBC() && getAB() > getAC()){
            return "AB es mayor";
        }else if(getBC()>getAB() && getBC()>getAC()){
            return "BC es mayor";
        }else if(getAC()>getAB() && getAC()>getBC()){
            return "AC es mayor";
        }
        return "Todos son iguales";
    }

    // no hay setters
    @Override
    public String toString(){
        return "Enigma a:" + a + ",b:" + b + ",c:" + c +
                ",v:" + Double.toString(v);
    }

    // metodos privados
    private int getAB() {
        return a*b;
    }
    private int getAC() {
        return a*c;
    }
    private int getBC() {
        return b*c;
    }
    private int queHace(){
        return a*b*c;
    }
}

