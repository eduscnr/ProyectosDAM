package com.example.enigmafxeduardoescribano.controller;

import com.example.enigmafxeduardoescribano.modelo.Enigma;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class ControllerEnigma implements Initializable {
    @FXML
    private Button btnCrear;
    @FXML
    private Button btnCalcular;
    @FXML
    private Button btnLimpiar;

    @FXML
    private TableView<Enigma> tableView;

    @FXML
    private ListView<Enigma> listViewEnigma;
    @FXML
    private TableColumn<Enigma, Boolean> columnaComprobar;

    @FXML
    private TableColumn<Enigma, Integer> columnaFrente;

    @FXML
    private TableColumn<Enigma, Integer> columnaLado;

    @FXML
    private TableColumn<Enigma, String> columnaMayor;

    @FXML
    private TableColumn<Enigma, Integer> columnaTapa;
    //TableView
    private ObservableList<Enigma> enigmasInformacion = FXCollections.observableArrayList();
    //ListView
    private ObservableList<Enigma> enigmasCalculados = FXCollections.observableArrayList();

    @FXML
    private Label lblVolumen;

    @FXML
    private TextField txfA;

    @FXML
    private TextField txfActual;

    @FXML
    private TextField txfB;

    @FXML
    private TextField txfC;

    @FXML
    private TextField txfTotalLista;
    @FXML
    private ImageView imgFoto;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        columnaFrente.setCellValueFactory(new PropertyValueFactory<>("a"));
        columnaLado.setCellValueFactory(new PropertyValueFactory<>("b"));
        columnaTapa.setCellValueFactory(new PropertyValueFactory<>("c"));
        columnaMayor.setCellValueFactory(new PropertyValueFactory<>("mayor"));
        columnaComprobar.setCellValueFactory(new PropertyValueFactory<>("comprobar"));
    }
    @FXML
    private void accionCrear() {
        int iA = 0, iB = 0, iC = 0;
        String sA, sB, sC;
        Enigma e;
        sA = txfA.getText().toString();
        sB = txfB.getText().toString();
        sC = txfC.getText().toString();
        System.out.println(sA);
        if(!sA.isEmpty() && !sB.isEmpty() && !sC.isEmpty()){
            iA = Integer.parseInt(sA);
            iB = Integer.parseInt(sB);
            iC = Integer.parseInt(sC);
        }
        if (iA > 0 && iB > 0 && iC > 0) {
            e = new Enigma(iA, iB, iC);
            lblVolumen.setText(String.valueOf(e.getV()));
        } else {
            e = new Enigma();
            lblVolumen.setText(String.valueOf(e.getV()));
        }
        enigmasInformacion.add(e);
        listViewEnigma.setItems(enigmasInformacion);
        txfTotalLista.setText(String.valueOf(enigmasInformacion.size()));
    }
    @FXML
    private void accionCalcular(){
        if(!enigmasInformacion.isEmpty()){
            Enigma ultimo = enigmasInformacion.get(enigmasInformacion.size() - 1);
            System.out.println(ultimo);
            //log.addLog("calculando frente, lado, tapa y mayor");
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Calcular");
            alert.setHeaderText("Realmente debes calcular las medidas de las caras: \n"
                    + "Frente, Lado, Tapa, y el mayor de ellos, \n"
                    + "y averiguar si es un cubo ...\n"
                    + ultimo.toString()
                    + "¿Estas preparado para calcular?");
            alert.showAndWait();
            String resut= alert.getResult().getText().toString();
            if(resut.equalsIgnoreCase("Aceptar")){
                enigmasCalculados.add(ultimo);
                tableView.setItems(enigmasCalculados);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Debes de crear un Enigma");
            alert.showAndWait();
        }
    }

    public void clickList(MouseEvent mouseEvent) {
        int index = listViewEnigma.getSelectionModel().getSelectedIndex();
        txfActual.setText(String.valueOf(index));
    }

    public void limpiar(ActionEvent actionEvent) {
        txfA.setText("");
        txfB.setText("");
        txfC.setText("");
        lblVolumen.setText("");

    }
}
