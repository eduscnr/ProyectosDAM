module com.example.enigmafxeduardoescribano {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.example.enigmafxeduardoescribano to javafx.fxml;
    exports com.example.enigmafxeduardoescribano;
    exports com.example.enigmafxeduardoescribano.modelo;
    exports com.example.enigmafxeduardoescribano.controller;
    opens com.example.enigmafxeduardoescribano.controller to javafx.fxml;
}