/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacionbarbero;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usumaniana
 */
public class Barbero extends Thread{
    private Barberia baberia;
    private String nombre;

    public Barbero(Barberia baberia, String nombre) {
        super(nombre);
        this.baberia = baberia;
        this.nombre = nombre;
    }
    @Override
    public void run(){
        int cliente;
        while(true){
            try {
                if((cliente = baberia.atenderCliente()) >= 0){
                    System.out.println("El barbero " + nombre  + " atiende al cliente sentado en la silla " + cliente);
                    sleep(2000);
                    baberia.liberarSillas(cliente);
                }else{
                    System.out.println("El barbero " + nombre + " se va a dormir porque no hay clientes");
                    sleep(2000);
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Barbero.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
