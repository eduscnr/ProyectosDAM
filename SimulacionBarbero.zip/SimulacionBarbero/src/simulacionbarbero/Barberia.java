/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacionbarbero;

/**
 *
 * @author usumaniana
 */
public class Barberia {

    private int numSillas;
    private boolean[] sillasDisponibles;
    private boolean[] atendido;
    private int clienterAAtender;

    public Barberia(int numSillas) {
        this.numSillas = numSillas;
        sillasDisponibles = new boolean[numSillas];
        atendido = new boolean[numSillas];
        for (int i = 0; i < numSillas; i++) {
            sillasDisponibles[i] = true;
        }
    }

    public synchronized int sentarse() {
        for (int i = clienterAAtender; i < numSillas; i++) {
            if (sillasDisponibles[i]) {
                sillasDisponibles[i] = false; //Se sienta
                atendido[i] = false;
                return i;//Le devolvemos al cliente el nº de silla
            }
        }
        return -1; //No hay sillas disponibles
    }

    public synchronized int atenderCliente() {
        int indice = clienterAAtender;
        boolean salir = false;
        while (!salir) {
            if (!sillasDisponibles[indice] && !atendido[indice]) {
                atendido[indice] = true;
                clienterAAtender = (clienterAAtender + 1) % numSillas;
                return indice;
            }
            indice++;
            if (indice == numSillas) {
                indice = 0;
            }
            if (indice == clienterAAtender) {
                salir = true;
            }
        }
        return -1;
    }

    public synchronized void liberarSillas(int silla) {
        sillasDisponibles[silla] = true;
        System.out.println("Cliente silla " + silla + " se marcha");
    }
}
