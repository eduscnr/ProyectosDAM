/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simulacionbarbero;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usumaniana
 */
public class SimulacionBarbero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final int NUM_SILLAS = 3;
        final int NUM_PELUQUERIOS = 2;
        final int NUM_CLIENTES = 10;
        Barberia barberia = new Barberia(NUM_SILLAS);
        Barbero barberos[] = new Barbero[NUM_PELUQUERIOS];
        Cliente clientes[] = new Cliente[NUM_CLIENTES];
        for (int i = 0; i < NUM_PELUQUERIOS; i++) {
            barberos[i] = new Barbero(barberia, "Barbero " + i);
            barberos[i].start();
        }
        for (int i = 0; i < NUM_CLIENTES; i++) {
            try {
                clientes[i] = new Cliente("Cliente " + i, barberia);
                clientes[i].start();
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SimulacionBarbero.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
