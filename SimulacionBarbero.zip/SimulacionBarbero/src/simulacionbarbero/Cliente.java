/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacionbarbero;

/**
 *
 * @author usumaniana
 */
public class Cliente extends Thread {

    private String nombre;
    private Barberia barbero;

    public Cliente(String nombre, Barberia barbero) {
        super(nombre);
        this.nombre = nombre;
        this.barbero = barbero;
    }

    @Override
    public void run() {
        int silla;
        if ((silla = barbero.sentarse()) != -1) {
            System.out.println("Cliente " + nombre + " se sienta en la silla " + silla);
        } else {
            System.out.println("Cliente " + nombre + " se marcha porque no hay sillas disponibles");
        }
    }

}
