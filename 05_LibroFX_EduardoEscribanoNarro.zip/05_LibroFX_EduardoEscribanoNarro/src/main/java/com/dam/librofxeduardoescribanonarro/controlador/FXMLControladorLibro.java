/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dam.librofxeduardoescribanonarro.controlador;

import com.dam.librofxeduardoescribanonarro.modelo.Libro;
import PaqueteSQT.BasicLog;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;


/**
 *
 * @author Eduardo
 */
public class FXMLControladorLibro implements Initializable {
    private BasicLog log = new BasicLog();
    
    
    private Label label;
    @FXML
    private Button btNuevo;
    @FXML
    private Button btLimpiar;
    @FXML
    private Button btListar;
    @FXML
    private Label lbEstado;
    @FXML
    private MenuItem mnListar;
    @FXML
    private MenuItem mnCerrar;
    @FXML
    private MenuItem mnAcercaDe;
    @FXML
    private MenuItem mnLimpiar;

    @FXML
    private Button btn_editar;

    @FXML
    private Button btn_eliminar;
    @FXML
    private TableView<Libro> tablaLibros;
    @FXML
    private TableColumn<Libro, String> columnaAutor;
    @FXML
    private TableColumn<Libro, String> columnaEditorail;
    @FXML
    private TableColumn<Libro, String> columnaISBN;

    @FXML
    private TableColumn<Libro, Double> columnaPrecio;

    @FXML
    private TableColumn<Libro, String> columnaTitulo;

    @FXML
    private TreeView treeView;
    @FXML
    TreeItem<String> hijos;
    private ObservableList<Libro> libroInformacion = FXCollections.observableArrayList();
    private Libro modelo_libro;
    private boolean click;

    public TreeView getTreeView() {
        return treeView;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        log.setDEBUG(false);
        log.addLog("Iniciando");
        hijos = new TreeItem<>("Editoriales");
        modelo_libro = new Libro();
        columnaTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        columnaAutor.setCellValueFactory(new PropertyValueFactory<>("autor"));
        columnaPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        columnaISBN.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        columnaEditorail.setCellValueFactory(new PropertyValueFactory<>("Editorial"));
        inicializarLibros();
        tablaLibros.setItems(libroInformacion);
        treeView.setRoot(hijos);
        llenarTreeViewConEditoriales();
        treeView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                TreeItem<String> indexSeleccionado = (TreeItem<String>) treeView.getSelectionModel().getSelectedItem();
                if(indexSeleccionado != null){
                    if(indexSeleccionado.getParent() != null){
                        String mensaje = "Nodo padre: " + indexSeleccionado.getParent().getValue() + ", Nodo hijo: " + indexSeleccionado.getValue();
                        System.out.println(mensaje);
                    }
                }
            }
        });
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        log.addLog(event.getSource().toString());
        mostrarDialogoLibroEditar(modelo_libro);
        if(click){
            log.addLog("Se ha añadido: " + modelo_libro.toString());
            libroInformacion.add(modelo_libro);
            llenarTreeViewConEditoriales();
            modelo_libro = new Libro();
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        log.addLog(event.getSource().toString());
        libroInformacion.clear();
        log.addLog("Ha borrado toda la infromación de la tabla");
    }

    @FXML
    private void accionListar(ActionEvent event) {
        log.addLog(event.getSource().toString());
        for (Libro l : libroInformacion){
            System.out.println(l.getAutor());
            System.out.println(l.getTitulo());
            System.out.println(l.getEditorial());
            System.out.println(l.getPrecio());
            System.out.println(l.getISBN());
        }
    }

    @FXML
    private void accionMenuAcercaDe(ActionEvent event) {
        log.addLog(event.getSource().toString());
        lbEstado.setText("Menu Acerca de...");
    }

    @FXML
    private void accionCerrar(ActionEvent event) {
        log.addLog(event.getSource().toString());
        lbEstado.setText("...Cerrando...");
        // Volcado del log en output
        log.dumpLog();
        // O traer el basicLog y recorrerlo
        // log.getBasicLog().forEach( linea -> { System.out.println(linea); });
        
        Platform.exit();
    }

    @FXML
    void editar(ActionEvent event) {
        log.addLog(event.getSource().toString());
        Libro seleccionLibro =tablaLibros.getSelectionModel().getSelectedItem();
        Libro libroTemporarl = seleccionLibro;
        if(seleccionLibro != null){
            mostrarDialogoLibroEditar(seleccionLibro);
            if(click){
                log.addLog("Se va a editar este alumno" + libroTemporarl);
                log.addLog("Alumno editado: " + seleccionLibro);
                llenarTreeViewConEditoriales();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Libro no seleccionada");
            alert.setHeaderText("Libro no seleccionada");
            alert.setContentText("Por favor selecciona a un libro en la tabla :)");
            log.addLog("Dialogo alerta por no seleccionar para editar.");

            alert.showAndWait();
        }

    }

    @FXML
    void eliminar(ActionEvent event) {
        log.addLog(event.getSource().toString());
        Libro seleccionLibro = tablaLibros.getSelectionModel().getSelectedItem();
        if (seleccionLibro != null){
            tablaLibros.getItems().remove(seleccionLibro);
            log.addLog("Alumno eliminado" + seleccionLibro);
            llenarTreeViewConEditoriales();
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("SELECCIONA");
            alert.setHeaderText("Selecciona una Libro");
            alert.setContentText("Por favor selecciona un libro para poder borrarlo");
            log.addLog("Dialogo alerta por no seleccionar para eliminar.");

            alert.showAndWait();
        }

    }
    public void inicializarLibros(){
       libroInformacion.add(new Libro("El Secreto del Tiempo", "Laura Martínez", "no se",24.99, "978-1234567890"));
       libroInformacion.add(new Libro("El Secreto del Tiempo", "Laura Martínez", "no se",24.99, "978-1234567890"));
       libroInformacion.add(new Libro("El Secreto del Tiempo", "Laura Martínez","no se", 24.99, "978-1234567890"));
       libroInformacion.add(new Libro("El Secreto del Tiempo", "Laura Martínez","no se", 24.99, "978-1234567890"));
       libroInformacion.add(new Libro("El Secreto del Tiempo", "Laura Martínez","no se", 24.99, "978-1234567890"));
       libroInformacion.add(new Libro("El Secreto del Tiempo", "Laura Martínez", "no se",24.99, "978-1234567890"));
       libroInformacion.add(new Libro("El Secreto del Tiempo", "Laura Martínez","no se", 24.99, "978-1234567890"));
       log.addLog("Inicializar datos de los libros");
    }
    public void mostrarDialogoLibroEditar(Libro libro) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLControladorLibro.class.getResource("/com/dam/librofxeduardoescribanonarro/VistaEditarLibro.fxml"));
        try {
            HBox raiz = loader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Editar/Añadir nuevo libro");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            Scene scene = new Scene(raiz);
            dialogStage.setScene(scene);
            ControllerEditarLibro controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setAplicacionPrincipal(this);
            controller.setLibro(libro);
            dialogStage.showAndWait();
            click = controller.isClick();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void llenarTreeViewConEditoriales() {
        hijos.getChildren().clear();
        for (Libro libro : libroInformacion) {
            String editorial = libro.getEditorial();

            TreeItem<String> editorialNode = buscarEditorial(editorial);

            if (editorialNode == null) {
                editorialNode = new TreeItem<>(editorial);
                hijos.getChildren().add(editorialNode);
            }

            TreeItem<String> libroNode = new TreeItem<>(libro.getTitulo());
            editorialNode.getChildren().add(libroNode);
        }
    }
    private TreeItem<String> buscarEditorial(String editorial) {
        for (TreeItem<String> editorialNode : hijos.getChildren()) {
            if (editorialNode.getValue().equals(editorial)) {
                return editorialNode;
            }
        }
        return null;
    }
}
