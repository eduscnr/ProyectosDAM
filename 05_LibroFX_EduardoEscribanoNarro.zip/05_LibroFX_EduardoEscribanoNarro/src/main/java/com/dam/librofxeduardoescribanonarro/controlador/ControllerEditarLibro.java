package com.dam.librofxeduardoescribanonarro.controlador;

import com.dam.librofxeduardoescribanonarro.modelo.Libro;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ControllerEditarLibro {
    @FXML
    private Button btn_cancelar;

    @FXML
    private Button btn_ok;

    @FXML
    private TextField txf_autor;

    @FXML
    private TextField txf_isbn;

    @FXML
    private TextField txf_precio;
    @FXML
    private TextField txf_editorial;

    @FXML
    private TextField txf_titulo;
    private Stage dialogStage;
    private Libro libro;

    public boolean isClick() {
        return click;
    }

    private FXMLControladorLibro aplicacionPrincipal;
    private boolean click = false;
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setAplicacionPrincipal(FXMLControladorLibro aplicacionPrincipal) {
        this.aplicacionPrincipal = aplicacionPrincipal;
    }

    public void setLibro(Libro libro){
        this.libro = libro;
        txf_titulo.setText(libro.getTitulo());
        txf_autor.setText(libro.getAutor());
        txf_editorial.setText(libro.getEditorial());
        txf_precio.setText(String.valueOf(libro.getPrecio()));
        txf_isbn.setText(libro.getISBN());
    }
    @FXML
    void accionOk(ActionEvent event) {
        click = true;
        libro.setTitulo(txf_titulo.getText());
        libro.setAutor(txf_autor.getText());
        libro.setEditorial(txf_editorial.getText());
        libro.setPrecio(Double.parseDouble(txf_precio.getText()));
        libro.setISBN(txf_isbn.getText());
        dialogStage.close();
    }

    @FXML
    void accionCancelar(ActionEvent event) {
        click = false;
        dialogStage.close();
    }
}
