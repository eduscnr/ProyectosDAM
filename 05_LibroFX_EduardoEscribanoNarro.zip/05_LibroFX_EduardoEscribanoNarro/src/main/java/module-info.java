module com.dam.librofxeduardoescribanonarro {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires LibSqt;


    opens com.dam.librofxeduardoescribanonarro to javafx.fxml;
    exports com.dam.librofxeduardoescribanonarro;
    exports com.dam.librofxeduardoescribanonarro.modelo;
    exports com.dam.librofxeduardoescribanonarro.controlador;
    opens com.dam.librofxeduardoescribanonarro.controlador to javafx.fxml;
}