package org.example.vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UsuarioContrasenia extends JDialog {
    private JPanel contentPane;
    private JTextField txf_usuario;
    private JPasswordField txf_contrasenia;
    private JButton btn_iniciar;
    private String usuario;
    private String contrasenia;
    public UsuarioContrasenia() {
        setContentPane(contentPane);
        setModal(true);
        btn_iniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                usuario = txf_usuario.getText();
                char[] contraseniaChars = txf_contrasenia.getPassword();
                contrasenia = new String(contraseniaChars);
                if(!usuario.equalsIgnoreCase("") && !contrasenia.equalsIgnoreCase("")){
                    dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Los campos de contraseña y usuario no pueden quedar vacios", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }
}
