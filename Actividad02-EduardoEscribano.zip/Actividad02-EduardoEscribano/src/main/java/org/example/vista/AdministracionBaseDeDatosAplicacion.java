package org.example.vista;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;

public class AdministracionBaseDeDatosAplicacion extends JDialog {
    private JPanel contentPane;
    private JTextArea txa_terminalSql;
    private JButton ejecutarButton;
    private JButton abrirScriptButton;
    private JList lst_tablas;
    private JList lst_columnas;
    private JList lst_primaryKey;
    private JList lst_foreignKay;
    private JTable tbl_resultadoSelect;
    private JList lst_historial;
    private JLabel lblcolumnasAfectadas;
    private DefaultTableModel dtmResultadosSet;
    private DefaultListModel dlmTable;
    private DefaultListModel dlmColumna;
    private  DefaultListModel dlmForeignKey;
    private DefaultListModel dlmPrimaryKey;
    private DefaultListModel dlmHistorial;
    AdministracionBaseDeDatosAplicacion(Connection conexion, FormularioAlumno formularioAlumno) {
        setContentPane(contentPane);
        setModal(true);
        dtmResultadosSet = new DefaultTableModel();
        dlmTable = new DefaultListModel();
        dlmColumna = new DefaultListModel();
        dlmForeignKey = new DefaultListModel();
        dlmPrimaryKey = new DefaultListModel();
        dlmHistorial = new DefaultListModel();
        lst_tablas.setModel(dlmTable);
        lst_columnas.setModel(dlmColumna);
        lst_foreignKay.setModel(dlmForeignKey);
        lst_primaryKey.setModel(dlmPrimaryKey);
        lst_historial.setModel(dlmHistorial);
        tbl_resultadoSelect.setModel(dtmResultadosSet);
        tablas(conexion);
        ejecutarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String secuentcia = txa_terminalSql.getText();
                String lineaDeSecuencias[] = secuentcia.split(";");
                PreparedStatement ejecutarSql = null;
                ResultSet resultadoSelect = null;
                for (String sentenciasSql : lineaDeSecuencias){
                    try {
                        ejecutarSql = conexion.prepareStatement(sentenciasSql);
                        if(ejecutarSql.execute()){
                            dtmResultadosSet.setRowCount(0);
                            dtmResultadosSet.setColumnCount(0);
                            resultadoSelect = ejecutarSql.getResultSet();
                            ResultSetMetaData metadatos = resultadoSelect.getMetaData();
                            int columnas = metadatos.getColumnCount();
                            for (int i = 1; i <= columnas; i++) {
                                dtmResultadosSet.addColumn(metadatos.getColumnName(i));
                            }
                            while (resultadoSelect.next()) {
                                Object[] filasConDatos = new Object[columnas];
                                for (int i = 1; i <= columnas; i++) {
                                    //resto i-1 porque los array empieza por cero
                                    filasConDatos[i - 1] = resultadoSelect.getObject(i);
                                }
                                dtmResultadosSet.addRow(filasConDatos);
                            }
                        }else{
                            int columnasAfectadas = ejecutarSql.getUpdateCount();
                            lblcolumnasAfectadas.setText(String.valueOf(columnasAfectadas));
                        }
                        tbl_resultadoSelect.revalidate();
                        dlmHistorial.addElement(sentenciasSql+";" + "\n");
                        formularioAlumno.mostrarDatos();
                        tablas(conexion);
                        txa_terminalSql.setText("");
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(getParent(), "Error: "+ e.getMessage() + "\n" + "Código del error: " + e.getErrorCode(), "Error" , JOptionPane.ERROR_MESSAGE);
                    }

                }
            }
        });
        lst_tablas.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent listSelectionEvent) {
                if(!listSelectionEvent.getValueIsAdjusting()){
                    String seleccionado = (String) lst_tablas.getSelectedValue();
                    if(seleccionado != null){
                        dlmColumna.clear();
                        ResultSet resultadoCulumna = null;
                        ResultSet foreignKey = null;
                        ResultSet primaryKey = null;
                        try {
                            DatabaseMetaData datosColumna = conexion.getMetaData();
                            resultadoCulumna = datosColumna.getColumns(null, null, seleccionado, null);;
                            while (resultadoCulumna.next()) {
                                String nombreColumna = resultadoCulumna.getString("COLUMN_NAME");
                                dlmColumna.addElement(nombreColumna);
                            }
                            dlmForeignKey.clear();
                            DatabaseMetaData datosForeign = conexion.getMetaData();
                            foreignKey = datosForeign.getImportedKeys(null, null, seleccionado);
                            while(foreignKey.next()){
                                String tablaReferenciada = foreignKey.getString("PKTABLE_NAME");
                                String columnaReferenciada = foreignKey.getString("PKCOLUMN_NAME");
                                dlmForeignKey.addElement(tablaReferenciada + " " + columnaReferenciada);
                            }
                            dlmPrimaryKey.clear();
                            DatabaseMetaData datosPrimaryKey = conexion.getMetaData();
                            primaryKey = datosPrimaryKey.getPrimaryKeys(null, null, seleccionado);
                            while(primaryKey.next()){
                                String nombreColumna = primaryKey.getString("COLUMN_NAME");
                                dlmPrimaryKey.addElement(nombreColumna);
                            }
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }finally {
                            try {
                                resultadoCulumna.close();
                                foreignKey.close();
                                primaryKey.close();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        }

                    }
                }
            }
        });
        lst_historial.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent listSelectionEvent) {
                int seleccion = lst_historial.getSelectedIndex();
                if(seleccion != -1){
                    txa_terminalSql.append((String) dlmHistorial.get(seleccion));
                }
                lst_historial.clearSelection();
            }
        });
        abrirScriptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JFileChooser jchose = new JFileChooser();
                jchose.showOpenDialog(null);
                File ficheroSql = jchose.getSelectedFile();
                if(ficheroSql.getName().contains(".sql")){
                    try {
                        FileReader fr = new FileReader(ficheroSql);
                        BufferedReader br = new BufferedReader(fr);
                        String linea;
                        String sentencia = "";
                        while((linea = br.readLine()) !=null){
                           txa_terminalSql.append(linea + "\n");
                        }
                    } catch (FileNotFoundException e) {
                        throw new RuntimeException(e);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    }
    public void tablas(Connection connection){
        try {
            dlmTable.clear();
            DatabaseMetaData datosEstamento = connection.getMetaData();
            String nombreEsquema = connection.getMetaData().getUserName();
            ResultSet resultadoTablas = datosEstamento.getTables(null, nombreEsquema,null, new String[] {"TABLE"});
            while (resultadoTablas.next()) {
                String tableName = resultadoTablas.getString("TABLE_NAME");
                dlmTable.addElement(tableName);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la recopilación de los metadatos");
        }
    }

}