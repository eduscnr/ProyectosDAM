package org.example.vista;

import org.example.basededatos.AdministrarBaseDeDatosOracle;
import org.example.basededatos.AdministrarBaseDeDatosSqlite;
import org.example.basededatos.AlumnoDAOImpl;
import org.example.modelo.Alumno;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FormularioAlumno {

    private JPanel jp_formulario;
    private JTable tbl_alumnos;
    private JMenu Conexiones;
    private JMenu CRUD;
    private JMenuItem nuevoAlumno;
    private JMenuItem editarAlumno;
    private JMenuItem eliminarAlumno;
    private JMenuItem conectarOracle;
    private JMenuItem conectarSQLite;
    private JMenu AplicacionDB;
    private JMenuItem aplicacionDB;
    private DefaultTableModel dtmAlumno;
    private AdministracionBaseDeDatosAplicacion abddaplicacion;
    private Connection conexion;
    private AlumnoDAOImpl alumnoDAOImpl;
    private EditarAlumnoNuevoAlumno editarAlumno_nuevoAlumno;
    private final FormularioAlumno formulario = this;

    public FormularioAlumno() {
        dtmAlumno = new DefaultTableModel();
        tbl_alumnos.setModel(dtmAlumno);
        final Alumno[] alumnoRecuperado = new Alumno[1];
        conectarSQLite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                AdministrarBaseDeDatosSqlite conexionDB = new AdministrarBaseDeDatosSqlite(new File("ficheros/DatosAlumnos.db"));
                conexion = conexionDB.getConexion();
                alumnoDAOImpl = new AlumnoDAOImpl(conexion);
                editarAlumno_nuevoAlumno = new EditarAlumnoNuevoAlumno(formulario, conexion);
                mostrarDatos();
            }
        });
        conectarOracle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                UsuarioContrasenia uc = new UsuarioContrasenia();
                uc.pack();
                uc.setVisible(true);
                if (uc.getContrasenia() != null && uc.getUsuario() != null && !uc.getUsuario().equalsIgnoreCase("") && !uc.getContrasenia().equalsIgnoreCase("")) {
                    AdministrarBaseDeDatosOracle conexionDBOracle = null;
                    try {
                        conexionDBOracle = new AdministrarBaseDeDatosOracle(uc.getUsuario(), uc.getContrasenia());
                        conexion = conexionDBOracle.getConexion();
                        alumnoDAOImpl = new AlumnoDAOImpl(conexion);
                        editarAlumno_nuevoAlumno = new EditarAlumnoNuevoAlumno(formulario, conexion);
                        mostrarDatos();
                        JOptionPane.showMessageDialog(null, "Te has conectado correctamente", "Infromativo", JOptionPane.INFORMATION_MESSAGE);
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "Usuario y contraseña errone, vuelva a intentarlo.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        tbl_alumnos.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent listSelectionEvent) {
                if (!listSelectionEvent.getValueIsAdjusting()) {
                    int seleccionado = tbl_alumnos.getSelectedRow();
                    if (seleccionado != -1) {
                        alumnoRecuperado[0] = alumnoSeleccioando(seleccionado);
                    }
                }
            }
        });
        editarAlumno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (alumnoRecuperado[0] != null) {
                    editarAlumno_nuevoAlumno.pack();
                    editarAlumno_nuevoAlumno.habilitarBotonEditarAlumno();
                    editarAlumno_nuevoAlumno.alumnoEditado(alumnoRecuperado[0], conexion);
                    editarAlumno_nuevoAlumno.setVisible(true);
                    alumnoRecuperado[0] = null;
                } else {
                    JOptionPane.showMessageDialog(null, "Debe de seleccionar algo en la tabla");
                }
                tbl_alumnos.clearSelection();
            }
        });
        nuevoAlumno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if(editarAlumno_nuevoAlumno != null){
                    editarAlumno_nuevoAlumno.habilitarBotonNuevoAlumno(conexion);
                    editarAlumno_nuevoAlumno.pack();
                    editarAlumno_nuevoAlumno.limpiarCampos();
                    editarAlumno_nuevoAlumno.setVisible(true);
                }

            }
        });
        eliminarAlumno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int filaSeleccionada = tbl_alumnos.getSelectedRow();
                if (filaSeleccionada != -1) {
                    alumnoRecuperado[0] = alumnoSeleccioando(filaSeleccionada);
                    if (alumnoRecuperado[0] != null) {
                        alumnoDAOImpl.eliminarAlumno(alumnoRecuperado[0].getId());
                        alumnoRecuperado[0] = null;
                        mostrarDatos();
                        tbl_alumnos.clearSelection();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un alumno en la tabla.");
                }
            }
        });
        aplicacionDB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if(conexion != null){
                    abddaplicacion = new AdministracionBaseDeDatosAplicacion(conexion, formulario);
                    abddaplicacion.pack();
                    abddaplicacion.setVisible(true);
                }
            }
        });
    }

    public void mostrarDatos() {
        String datosAlumnos = "Select * from alumnos";
        PreparedStatement statement = null;
        dtmAlumno.setRowCount(0);
        dtmAlumno.setColumnCount(0);
        try {
            statement = conexion.prepareStatement(datosAlumnos);
            ResultSet resultado = statement.executeQuery();
            ResultSetMetaData metadatos = resultado.getMetaData();
            int columnas = metadatos.getColumnCount();
            for (int i = 1; i <= columnas; i++) {
                dtmAlumno.addColumn(metadatos.getColumnName(i));
            }
            while (resultado.next()) {
                Object[] filasConDatos = new Object[columnas];
                for (int i = 1; i <= columnas; i++) {
                    filasConDatos[i - 1] = resultado.getObject(i);
                }
                dtmAlumno.addRow(filasConDatos);
            }
        } catch (SQLException e) {
            if(e.getErrorCode() == 942){
                System.out.println("No exite la tabla alumnos");
            }
        }

    }

    public Alumno alumnoSeleccioando(int alumnoSeleccionado) {
        Object idObject = dtmAlumno.getValueAt(alumnoSeleccionado, 0);
        int id;
        if (idObject instanceof BigDecimal) {
            id = ((BigDecimal) idObject).intValue();
        } else {
            id = (Integer) idObject;
        }
        String nombre = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 1);
        String apellido = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 2);
        String email = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 3);
        String poblacion = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 4);
        String telefono = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 5);
        String ciclo = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 6);
        String ordenador = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 7);
        String siCarnetS = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 8);
        Object fechaNacObject = dtmAlumno.getValueAt(alumnoSeleccionado, 9);
        Timestamp fechaNacTimestamp = null;
        if (fechaNacObject instanceof Timestamp) {
            fechaNacTimestamp = (Timestamp) fechaNacObject;
        } else if (fechaNacObject instanceof Long) {
            fechaNacTimestamp = new Timestamp((Long) fechaNacObject);
        }
        Date fechaNac = new Date(fechaNacTimestamp.getTime());
        String motivacion = (String) dtmAlumno.getValueAt(alumnoSeleccionado, 10);
        boolean siCarnet;
        if (siCarnetS.equalsIgnoreCase("si")) {
            siCarnet = true;
        } else {
            siCarnet = false;
        }
        List<String> estudios = alumnoDAOImpl.recuperarEstudiosPorAlumno(id);
        List<String> hobbies = alumnoDAOImpl.recuperarHobbiesPorAlumno(id);
        Alumno alumnoRecuperado = new Alumno(nombre, apellido, email, poblacion, telefono, Alumno.ciclos.valueOf(ciclo), Alumno.prestaciones.valueOf(ordenador), siCarnet, estudios, fechaNac, Alumno.motivaciones.valueOf(motivacion), hobbies);
        alumnoRecuperado.setId(id);
        return alumnoRecuperado;

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("FormularioAlumno");
        frame.setContentPane(new FormularioAlumno().jp_formulario);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
    }
}
