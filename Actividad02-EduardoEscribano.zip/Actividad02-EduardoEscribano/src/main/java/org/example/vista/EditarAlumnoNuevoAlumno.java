package org.example.vista;

import org.example.basededatos.AlumnoDAOImpl;
import org.example.modelo.Alumno;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EditarAlumnoNuevoAlumno extends JDialog {
    private JPanel contentPane;
    private JCheckBox FPBásicaCheckBox;
    private JCheckBox ESOCheckBox;
    private JComboBox comboBox1;
    private JRadioButton siRadioButton;
    private JRadioButton noRadioButton;
    private JRadioButton muyMotivadoRadioButton;
    private JCheckBox leerCheckBox;
    private JRadioButton a1RadioButton;
    private JRadioButton a2RadioButton;
    private JRadioButton a3RadioButton;
    private JRadioButton a4RadioButton;
    private JRadioButton a5RadioButton;
    private JRadioButton moderadamenteMotivadoRadioButton;
    private JRadioButton pocoMotivadoRadioButton;
    private JTextField txt_nombre;
    private JCheckBox jardíneriaCheckBox;
    private JCheckBox practicarDeporteCheckBox;
    private JCheckBox hacerDeporteCheckBox;
    private JCheckBox pintarDibujarCheckBox;
    private JCheckBox musicaCheckBox;
    private JCheckBox cocinarHornearCheckBox;
    private JCheckBox fotografíaCheckBox;
    private JCheckBox videojuegoCheckBox;
    private JCheckBox verPeliculaSeriesCheckBox;
    private JCheckBox coleccionarCheckBox;
    private JCheckBox senderísmoActividadesAlAireCheckBox;
    private JCheckBox voluntariadoActividadesBeneficiariasCheckBox;
    private JCheckBox otrosCheckBox;
    private JCheckBox juegosDeMesaCheckBox;
    private JTextField txt_apellidos;
    private JTextField txt_email;
    private JTextField txt_telefono;
    private JTextField txt_localidad;
    private JTextField txt_fechNacimiento;
    private JCheckBox bachilleratoCheckBox;
    private JCheckBox FPGradoMedioCheckBox;
    private JCheckBox FPGradoSuperiorCheckBox;
    private JCheckBox otrosEstudiosCheckBox;
    private JButton editarButton;
    private JButton nuevoAlumnoButton;
    private boolean editando;
    private Connection conexionDB;
    private ButtonGroup radioButtonPrestaciones;
    private ButtonGroup radioButtonCarnet;
    private ButtonGroup radioButtonMotivacion;
    private int idAlumnoEditado = 0;
    private AlumnoDAOImpl alumnos;
    private AlumnoDAOImpl alumnoDAOImpl;

    public EditarAlumnoNuevoAlumno(FormularioAlumno formularioAlumno, Connection conexion) {
        setContentPane(contentPane);
        setModal(true);
        alumnoDAOImpl = new AlumnoDAOImpl(conexion);
        comboBox1.addItem("DAM");
        comboBox1.addItem("DAW");
        comboBox1.addItem("ASIR");
        aniadirRadioButton();
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Alumno alumnoEditado = null;
                try {
                    alumnoEditado = recopilarDatos();
                    if(alumnoEditado != null){
                        alumnoEditado.setId(idAlumnoEditado);
                        alumnoDAOImpl.actualizarAlumno(alumnoEditado);
                        formularioAlumno.mostrarDatos();
                    }else{
                        JOptionPane.showMessageDialog(null, "El nombre, el apellido y la fecha de nacimiento no puede quedar vacio", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (ParseException e) {
                    JOptionPane.showMessageDialog(null, "Problema con la fecha, la forma correcta es: yyyy-mm-dd", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        nuevoAlumnoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Alumno alumno = null;
                try {
                    alumno = recopilarDatos();
                    if(alumno != null){
                        alumnoDAOImpl.nuevoAlumno(alumno);
                        formularioAlumno.mostrarDatos();
                    }else{
                        JOptionPane.showMessageDialog(null, "El nombre, el apellido y la fecha de nacimiento no puede quedar vacio", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (ParseException e) {
                    JOptionPane.showMessageDialog(null, "Problema con la fecha, la forma correcta es: yyyy-mm-dd", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public void alumnoEditado(Alumno alumno, Connection conexion) {
        conexionDB = conexion;
        idAlumnoEditado = alumno.getId();
        txt_nombre.setText(alumno.getNombre());
        txt_apellidos.setText(alumno.getApellido());
        txt_email.setText(alumno.getEmail());
        txt_localidad.setText(alumno.getPoblacion());
        txt_telefono.setText(alumno.getTelefono());
        txt_fechNacimiento.setText(alumno.getFechNac().toString());
        for (String estudios : alumno.getEstudios()) {
            String estudioLimpio = estudios.trim();
            if (estudioLimpio.equalsIgnoreCase("Eso")) {
                ESOCheckBox.setSelected(true);
            } else if (estudioLimpio.equalsIgnoreCase("BACHILLERATO")) {
                bachilleratoCheckBox.setSelected(true);
            } else if (estudioLimpio.equalsIgnoreCase("FP BÁSICA")) {
                FPBásicaCheckBox.setSelected(true);
            } else if (estudioLimpio.equalsIgnoreCase("Ciclo FP grado medio")) {
                FPGradoMedioCheckBox.setSelected(true);
            } else if (estudioLimpio.equalsIgnoreCase("Ciclo FP grado superior")) {
                FPGradoSuperiorCheckBox.setSelected(true);
            } else if (estudioLimpio.equalsIgnoreCase("Otros")) {
                otrosEstudiosCheckBox.setSelected(true);
            }
        }
        Alumno.ciclos ciclo = alumno.getCiclo();
        switch (ciclo) {
            case DAM:
                comboBox1.setSelectedItem("DAM");
                break;
            case ASIR:
                comboBox1.setSelectedItem("ASIR");
                break;
            case DAW:
                comboBox1.setSelectedItem("DAW");
                break;
        }
        Alumno.prestaciones prestacionesOrdenador = alumno.getOrdenador();
        switch (prestacionesOrdenador) {
            case UNO:
                a1RadioButton.setSelected(true);
                break;
            case DOS:
                a2RadioButton.setSelected(true);
                break;
            case TRES:
                a3RadioButton.setSelected(true);
                break;
            case CUATRO:
                a4RadioButton.setSelected(true);
                break;
            case CINCO:
                a5RadioButton.setSelected(true);
                break;
        }
        if (alumno.isSiCarnet()) {
            siRadioButton.setSelected(true);
        } else {
            noRadioButton.setSelected(true);
        }
        Alumno.motivaciones motivacione = alumno.getMotivacion();
        switch (motivacione) {
            case MODERADAMENTE_MOTIVADO:
                moderadamenteMotivadoRadioButton.setSelected(true);
                break;
            case POCO_MOTIVADO:
                pocoMotivadoRadioButton.setSelected(true);
                break;
            case MUY_MOTIVADO:
                muyMotivadoRadioButton.setSelected(true);
                break;
        }
        for (String hobbie : alumno.getHobbies()) {
            String hobbieLimpio = hobbie.trim();
            if (hobbieLimpio.equalsIgnoreCase("leer libros")) {
                leerCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("practicar deportes (menciona deportes específicos)")) {
                practicarDeporteCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("hacer ejercicio")) {
                hacerDeporteCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("pintura o dibujo")) {
                pintarDibujarCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("música (tocar un instrumento musical o escuchar música)")) {
                musicaCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("cocinar o hornear")) {
                cocinarHornearCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("jardinería")) {
                jardíneriaCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("fotografía")) {
                fotografíaCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("juegos de mesa")) {
                juegosDeMesaCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("videojuegos")) {
                videojuegoCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("ver películas o series")) {
                verPeliculaSeriesCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("Coleccionar")) {
                coleccionarCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("senderismo o actividades al aire libre")) {
                senderísmoActividadesAlAireCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("voluntariado-actividades beneficiarias")) {
                voluntariadoActividadesBeneficiariasCheckBox.setSelected(true);
            } else if (hobbieLimpio.equalsIgnoreCase("Otros")) {
                otrosCheckBox.setSelected(true);
            }
        }
    }

    private Alumno recopilarDatos() throws ParseException {
        Alumno alumnoEditado = new Alumno();
        List<String> estudios = new ArrayList<>();
        List<String> hobbies = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date fechaNac = null;
        alumnoEditado.setNombre(txt_nombre.getText());
        alumnoEditado.setApellido(txt_apellidos.getText());
        alumnoEditado.setEmail(txt_email.getText());
        alumnoEditado.setTelefono(txt_telefono.getText());
        alumnoEditado.setPoblacion(txt_localidad.getText());
        fechaNac = sdf.parse(txt_fechNacimiento.getText());
        alumnoEditado.setFechNac(fechaNac);
        if(!alumnoEditado.getNombre().equalsIgnoreCase("") && !alumnoEditado.getApellido().equalsIgnoreCase("") && fechaNac != null){
            if (ESOCheckBox.isSelected()) {
                estudios.add("ESO");
            }
            if (bachilleratoCheckBox.isSelected()) {
                estudios.add("Bachillerato");
            }
            if (FPBásicaCheckBox.isSelected()) {
                estudios.add("FP Básica");
            }
            if (FPGradoSuperiorCheckBox.isSelected()) {
                estudios.add("Ciclo FP grado superior");
            }
            if (FPGradoMedioCheckBox.isSelected()) {
                estudios.add("Ciclo FP grado medio");
            }
            if (otrosEstudiosCheckBox.isSelected()) {
                estudios.add("Otros");
            }
            alumnoEditado.setEstudios(estudios);
            String cicloSeleccionado = comboBox1.getSelectedItem().toString();
            alumnoEditado.setCiclo(Alumno.ciclos.valueOf(cicloSeleccionado));
            if (a1RadioButton.isSelected()) {
                alumnoEditado.setOrdenador(Alumno.prestaciones.UNO);
            } else if (a2RadioButton.isSelected()) {
                alumnoEditado.setOrdenador(Alumno.prestaciones.DOS);
            } else if (a3RadioButton.isSelected()) {
                alumnoEditado.setOrdenador(Alumno.prestaciones.TRES);
            } else if (a4RadioButton.isSelected()) {
                alumnoEditado.setOrdenador(Alumno.prestaciones.CUATRO);
            } else if (a5RadioButton.isSelected()) {
                alumnoEditado.setOrdenador(Alumno.prestaciones.CINCO);
            }

            if (siRadioButton.isSelected()) {
                alumnoEditado.setSiCarnet(true);
            } else {
                alumnoEditado.setSiCarnet(false);
            }

            if (moderadamenteMotivadoRadioButton.isSelected()) {
                alumnoEditado.setMotivacion(Alumno.motivaciones.MODERADAMENTE_MOTIVADO);
            } else if (pocoMotivadoRadioButton.isSelected()) {
                alumnoEditado.setMotivacion(Alumno.motivaciones.POCO_MOTIVADO);
            } else if (muyMotivadoRadioButton.isSelected()) {
                alumnoEditado.setMotivacion(Alumno.motivaciones.MUY_MOTIVADO);
            }

            if (leerCheckBox.isSelected()) {
                hobbies.add("leer libros");
            }
            if (practicarDeporteCheckBox.isSelected()) {
                hobbies.add("practicar deportes (menciona deportes específicos)");
            }
            if (hacerDeporteCheckBox.isSelected()) {
                hobbies.add("hacer ejercicio");
            }
            if (pintarDibujarCheckBox.isSelected()) {
                hobbies.add("pintura o dibujo");
            }
            if (musicaCheckBox.isSelected()) {
                hobbies.add("música (tocar un instrumento musical o escuchar música)");
            }
            if (cocinarHornearCheckBox.isSelected()) {
                hobbies.add("cocinar o hornear");
            }
            if (jardíneriaCheckBox.isSelected()) {
                hobbies.add("jardinería");
            }
            if (fotografíaCheckBox.isSelected()) {
                hobbies.add("fotografía");
            }
            if (juegosDeMesaCheckBox.isSelected()) {
                hobbies.add("juegos de mesa");
            }
            if (videojuegoCheckBox.isSelected()) {
                hobbies.add("videojuegos");
            }
            if (verPeliculaSeriesCheckBox.isSelected()) {
                hobbies.add("ver películas o series");
            }
            if (coleccionarCheckBox.isSelected()) {
                hobbies.add("coleccionar");
            }
            if (senderísmoActividadesAlAireCheckBox.isSelected()) {
                hobbies.add("senderismo o actividades al aire libre");
            }
            if (voluntariadoActividadesBeneficiariasCheckBox.isSelected()) {
                hobbies.add("voluntariado-actividades beneficiarias");
            }
            if (otrosCheckBox.isSelected()) {
                hobbies.add("Otros");
            }
            alumnoEditado.setHobbies(hobbies);
            return  alumnoEditado;
        }else{
            return null;
        }
    }

    public void habilitarBotonNuevoAlumno(Connection conexion) {
        editarButton.setEnabled(false);
        nuevoAlumnoButton.setEnabled(true);
        conexionDB = conexion;
    }

    public void habilitarBotonEditarAlumno() {
        editarButton.setEnabled(true);
        nuevoAlumnoButton.setEnabled(false);
    }

    private void aniadirRadioButton() {
        radioButtonPrestaciones = new ButtonGroup();
        radioButtonCarnet = new ButtonGroup();
        radioButtonMotivacion = new ButtonGroup();
        radioButtonMotivacion.add(muyMotivadoRadioButton);
        radioButtonMotivacion.add(moderadamenteMotivadoRadioButton);
        radioButtonMotivacion.add(pocoMotivadoRadioButton);
        radioButtonCarnet.add(siRadioButton);
        radioButtonCarnet.add(noRadioButton);
        radioButtonPrestaciones.add(a1RadioButton);
        radioButtonPrestaciones.add(a2RadioButton);
        radioButtonPrestaciones.add(a3RadioButton);
        radioButtonPrestaciones.add(a4RadioButton);
        radioButtonPrestaciones.add(a5RadioButton);
    }

    public void limpiarCampos() {
        txt_nombre.setText("");
        txt_apellidos.setText("");
        txt_email.setText("");
        txt_localidad.setText("");
        txt_telefono.setText("");
        txt_fechNacimiento.setText("");
        bachilleratoCheckBox.setSelected(false);

        FPBásicaCheckBox.setSelected(false);
        ESOCheckBox.setSelected(false);
        FPGradoMedioCheckBox.setSelected(false);
        FPGradoSuperiorCheckBox.setSelected(false);
        otrosEstudiosCheckBox.setSelected(false);

        radioButtonPrestaciones.clearSelection();
        radioButtonCarnet.clearSelection();
        radioButtonMotivacion.clearSelection();

        comboBox1.setSelectedIndex(0);

        leerCheckBox.setSelected(false);
        practicarDeporteCheckBox.setSelected(false);
        hacerDeporteCheckBox.setSelected(false);
        pintarDibujarCheckBox.setSelected(false);
        musicaCheckBox.setSelected(false);
        cocinarHornearCheckBox.setSelected(false);
        jardíneriaCheckBox.setSelected(false);
        fotografíaCheckBox.setSelected(false);
        juegosDeMesaCheckBox.setSelected(false);
        videojuegoCheckBox.setSelected(false);
        verPeliculaSeriesCheckBox.setSelected(false);
        coleccionarCheckBox.setSelected(false);
        senderísmoActividadesAlAireCheckBox.setSelected(false);
        voluntariadoActividadesBeneficiariasCheckBox.setSelected(false);
        otrosCheckBox.setSelected(false);

    }
}
