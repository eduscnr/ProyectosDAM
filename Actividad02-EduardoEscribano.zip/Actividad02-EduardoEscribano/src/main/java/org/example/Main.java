package org.example;

import org.example.basededatos.AdministrarBaseDeDatosOracle;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        /*int nextId = 1;
        AdministrarBaseDeDatos bd = new AdministrarBaseDeDatos("/home/alumno/prueba.db");
        System.out.println("Realizada");
        bd.crearTablas("Estudios",
                "idEstudio int primary key,"+
                        "nombreEstudio varchar(50)"
        );
        bd.crearTablas("Hobbies",
                "idHobby int PRIMARY KEY,"+
                        "nombreHobby varchar(50)"
        );
        bd.crearTablas("Alumnos",
                "id INTEGER primary key,"+
                        "nombre varchar(100)," +
                        "apellidos varchar(100),"+
                        "email varchar(50),"+"poblacion varchar(50),"+"telefono varchar(10),"+
                        "ciclo varchar(20)," + "ordenador varchar(10)," + "siCarnet varchar(2)," +
                        "fechNac date," + "motivacion varchar(20)"
        );
        bd.crearTablas("AlumnosEstudios",
                "idAlumno int,"+
                        "idEstudio int,"+
                        "FOREIGN KEY (idAlumno) REFERENCES Alumnos(id),"+
                        "FOREIGN KEY (idEstudio) REFERENCES Estudios(idEstudio)"
        );
        bd.crearTablas("AlumnosHobbies",
                "idAlumno int,"+
                        "idHobby int,"+
                        "FOREIGN KEY (idAlumno) REFERENCES Alumnos(id),"+
                        "FOREIGN KEY (idHobby) REFERENCES Hobbies(idHobby)"
        );

        bd.insertarDatosAlumnos();
        bd.insertarDatosEstudios();
        bd.insertarDatosHobbies();
        bd.insertarAlumnosEstudios();
        bd.insertarAlumnosHobbies();
        /*List<Alumno> alumnos = LeerJson.recuperarDatos("ficheros/alumnos.json");
        for (Alumno alumno : alumnos){
            for (String estudio : alumno.getHobbies()){
                System.out.println(estudio);
            }
        }
        System.out.println("Proceso de recuperar datos");
        AlumnoDAO recuperarAlumno = new AlumnoDAO(bd.getConexion());
        List<Alumno> alumnos = recuperarAlumno.recuperarTodosLosAlumnos();
        for(Alumno alumno : alumnos){
            System.out.println("---------------------------");
            System.out.println(alumno.getId());
            System.out.println(alumno.getNombre());
            System.out.println(alumno.getApellido());
            System.out.println(alumno.getEmail());
            System.out.println(alumno.getPoblacion());
            System.out.println(alumno.getTelefono());
            System.out.println(alumno.getCiclo());
            System.out.println(alumno.getOrdenador());
            System.out.println(alumno.isSiCarnet());
            System.out.println(alumno.getEstudios());
            System.out.println(alumno.getFechNac());
            System.out.println(alumno.getMotivacion());
            System.out.println(alumno.getHobbies());
            System.out.println("---------------------------");
        }*/
    }
}