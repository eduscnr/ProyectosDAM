package org.example.modelo;

import java.util.Date;
import java.util.List;

public class Alumno {
    public enum ciclos{
        ASIR,DAM,DAW
    }
    public enum motivaciones{
        MUY_MOTIVADO,MODERADAMENTE_MOTIVADO,POCO_MOTIVADO
    }
    public enum prestaciones{
        UNO(1),
        DOS(2),
        TRES(3),
        CUATRO(4),
        CINCO(5);
        private int id;

        private prestaciones(int id){
            this.id = id;
        }
        public int getValor(){
            return this.id;
        }
    }
    private String nombre;
    private String apellido;
    private String email;
    private String poblacion;
    private String telefono;
    private ciclos ciclo;
    private prestaciones ordenador;
    private boolean siCarnet;
    private List<String> estudios;
    private Date fechNac;
    private motivaciones motivacion;
    private List<String> hobbies;
    private int id;
    private static int nextId = 1;

    public Alumno() {
    }

    public Alumno(String nombre, String apellido, String email, String poblacion, String telefono, ciclos ciclo,
                  prestaciones ordenador, boolean siCarnet, List<String> estudios, Date fechNac,
                  motivaciones motivacion, List<String> hobbies) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.poblacion = poblacion;
        this.telefono = telefono;
        this.ciclo = ciclo;
        this.ordenador = ordenador;
        this.siCarnet = siCarnet;
        this.estudios = estudios;
        this.fechNac = fechNac;
        this.motivacion = motivacion;
        this.hobbies = hobbies;
        id = nextId;
        nextId++;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public ciclos getCiclo() {
        return ciclo;
    }

    public void setCiclo(ciclos ciclo) {
        this.ciclo = ciclo;
    }

    public prestaciones getOrdenador() {
        return ordenador;
    }

    public void setOrdenador(prestaciones ordenador) {
        this.ordenador = ordenador;
    }

    public boolean isSiCarnet() {
        return siCarnet;
    }

    public void setSiCarnet(boolean siCarnet) {
        this.siCarnet = siCarnet;
    }

    public List<String> getEstudios() {
        return estudios;
    }

    public void setEstudios(List<String> estudios) {
        this.estudios = estudios;
    }

    public Date getFechNac() {
        return fechNac;
    }

    public void setFechNac(Date fechNac) {
        this.fechNac = fechNac;
    }

    public motivaciones getMotivacion() {
        return motivacion;
    }

    public void setMotivacion(motivaciones motivacion) {
        this.motivacion = motivacion;
    }

    public List<String> getHobbies() {
        return hobbies;
    }

    public void setHobbies(List<String> hobbies) {
        this.hobbies = hobbies;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "id= " + id+ '\'' +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", email='" + email + '\'' +
                ", poblacion='" + poblacion + '\'' +
                ", telefono='" + telefono + '\'' +
                ", ciclo=" + ciclo +
                ", ordenador=" + ordenador +
                ", siCarnet=" + siCarnet +
                ", estudios=" + estudios +
                ", fechNac=" + fechNac +
                ", motivacion=" + motivacion +
                ", hobbies=" + hobbies +
                '}';
    }
}

