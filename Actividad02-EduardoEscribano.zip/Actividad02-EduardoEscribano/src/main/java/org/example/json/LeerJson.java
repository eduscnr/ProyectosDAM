package org.example.json;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.example.modelo.Alumno;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class LeerJson {
    public static List<Alumno> recuperarDatos(String ruta){
        List<Alumno> alumnos;
        int nextId = 1;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            alumnos = objectMapper.readValue(new File(ruta), new TypeReference<List<Alumno>>() {});
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (JsonMappingException e) {
            throw new RuntimeException(e);
        } catch (JsonParseException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        for (Alumno alumno : alumnos){
            alumno.setId(nextId);
            nextId++;
        }

        return alumnos;
    }
}
