package org.example.basededatos;

import org.example.modelo.Alumno;

import java.util.List;

public interface AlumnoDAO {
    List<String> recuperarHobbiesPorAlumno(int idAlumno);
    List<String> recuperarEstudiosPorAlumno(int idAlumno);
    void eliminarAlumno(int idAlumno);
    void actualizarAlumno(Alumno alumno);
    void nuevoAlumno(Alumno alumno);
}
