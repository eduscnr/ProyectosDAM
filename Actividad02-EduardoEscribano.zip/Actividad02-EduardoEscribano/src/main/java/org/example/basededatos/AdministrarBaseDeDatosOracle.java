package org.example.basededatos;

import org.example.json.LeerJson;
import org.example.modelo.Alumno;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdministrarBaseDeDatosOracle {
    private Connection conexion;
    private boolean exite = false;

    public AdministrarBaseDeDatosOracle(String usuario, String contraseña) throws SQLException {
        conexion = conexionBaseDeDatos(usuario, contraseña);
        if(!exite){
            System.out.println("el usuario no exita y se ha creado");
            crearTablas();
        }
    }
    private Connection conexionBaseDeDatos(String usuario, String contraseña) throws SQLException {
        Connection connection = null;
        String url = "jdbc:oracle:thin:@localhost:1521/XE";
        String usuarioSystem = "system";
        String contraseñaSystem = "toor";
        PreparedStatement verificar = null;
        ResultSet resultado = null;
            connection = DriverManager.getConnection(url, usuarioSystem, contraseñaSystem);
            String verificarExitenciaUsuario = "SELECT COUNT(*) FROM dba_users WHERE username = ?";
            verificar = connection.prepareStatement(verificarExitenciaUsuario);
            verificar.setString(1, usuario.toUpperCase());
            resultado = verificar.executeQuery();
            resultado.next();
            int count = resultado.getInt(1);//Devuelve 0 si no existe y 1 si exite
            if(count ==0){
                String crearUsuarioSQL = "CREATE USER " + usuario.toUpperCase() + " IDENTIFIED BY " + contraseña;
                verificar = connection.prepareStatement(crearUsuarioSQL);
                verificar.executeUpdate();

                // Otorgar privilegios al nuevo usuario (por ejemplo, CONNECT y RESOURCE)
                String otorgarPrivilegiosSQL = "GRANT CONNECT, RESOURCE TO " + usuario.toUpperCase();
                verificar = connection.prepareStatement(otorgarPrivilegiosSQL);
                verificar.executeUpdate();
                connection.close();
                connection = DriverManager.getConnection(url, usuario.toUpperCase(), contraseña);

                System.out.println("Usuario creado exitosamente.");
            }else{
                exite = true;
                System.out.println("El usuario ya exite");
                connection.close();
                connection = DriverManager.getConnection(url, usuario.toUpperCase(), contraseña);
            }
        return connection;
    }
    private void crearTablas(String nombreTabla, String estructuraTabla){
        try {
            Statement statement = conexion.createStatement();
            String createTableSQL = "CREATE TABLE " + nombreTabla + " (" + estructuraTabla + ")";
            statement.executeUpdate(createTableSQL);
            statement.close();

        } catch (SQLException e) {
            System.err.println("Error al crear la tabla: " + e.getMessage());
        }
    }
    public void insertarDatosAlumnos() {
        String sentenciaSql = "INSERT INTO Alumnos VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        List<Alumno> alumnos = LeerJson.recuperarDatos("ficheros/alumnos.json");
        long tiempo = 0;
        Timestamp sqlTimestamp = null;
        PreparedStatement estamento = null;
        try {
            estamento = conexion.prepareStatement(sentenciaSql);
            for (Alumno alumno : alumnos) {
                estamento.setInt(1, alumno.getId());
                estamento.setString(2, alumno.getNombre());
                estamento.setString(3, alumno.getApellido());
                estamento.setString(4, alumno.getEmail());
                estamento.setString(5, alumno.getPoblacion());
                estamento.setString(6, alumno.getTelefono());
                estamento.setString(7, alumno.getCiclo().toString());
                estamento.setString(8, alumno.getOrdenador().toString());
                if (alumno.isSiCarnet()) {
                    estamento.setString(9, "Si");
                } else {
                    estamento.setString(9, "No");
                }
                tiempo = alumno.getFechNac().getTime();
                sqlTimestamp = new Timestamp(tiempo);
                estamento.setTimestamp(10, sqlTimestamp);
                estamento.setString(11, alumno.getMotivacion().toString());
                estamento.execute();
            }
        } catch (SQLException e) {
            System.err.println("Error en la inserción de datos en la tabla Alumnos: " + e.getErrorCode());
        }finally {
            try {
                estamento.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void insertarDatosEstudios(){
        String sentenciaSql = "INSERT INTO Estudios VALUES (?,?)";
        List<String> estudios = estudiosLista();
        int id = 1;
        PreparedStatement estamento = null;
        try {
            estamento = conexion.prepareStatement(sentenciaSql);
            for(String estudio : estudios){
                estamento.setInt(1, id);
                estamento.setString(2, estudio);
                estamento.execute();
                id++;
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }finally {
            try {
                estamento.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void insertarDatosHobbies(){
        String sentenciaSql = "INSERT INTO Hobbies VALUES (?,?)";
        List<String> hobbies = hobbiesLista();
        int id = 1;
        PreparedStatement estamento = null;
        try {
            estamento = conexion.prepareStatement(sentenciaSql);
            for(String hobbis : hobbies){
                estamento.setInt(1, id);
                estamento.setString(2, hobbis.toLowerCase());
                estamento.execute();
                id++;
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }finally {
            try {
                estamento.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void insertarAlumnosEstudios(){
        String sentenciaSql = "INSERT INTO AlumnosEstudios VALUES (?,?)";
        int idEstudio, idAlumno;
        PreparedStatement estamento = null;
        try {
            estamento = conexion.prepareStatement(sentenciaSql);
            List<Alumno> alumnos = LeerJson.recuperarDatos("ficheros/alumnos.json");
            for (Alumno alumno : alumnos){
                idAlumno = alumno.getId();
                for (String estudio : alumno.getEstudios()){
                    idEstudio = obtenerId("idEstudio","Estudios","nombreEstudio",estudio.trim());
                    if(idEstudio != -1){
                        estamento.setInt(1, idAlumno);
                        estamento.setInt(2, idEstudio);
                        estamento.executeUpdate();

                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }finally {
            try {
                estamento.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void insertarAlumnosHobbies(){
        String sentenciaSql = "INSERT INTO AlumnosHobbies VALUES (?,?)";
        int idHobbies, idAlumno;
        PreparedStatement estamento = null;
        try {
            estamento = conexion.prepareStatement(sentenciaSql);
            List<Alumno> alumnos = LeerJson.recuperarDatos("ficheros/alumnos.json");
            for (Alumno alumno : alumnos){
                idAlumno = alumno.getId();
                for (String hobbie : alumno.getHobbies()){
                    idHobbies = obtenerId("idHobby","Hobbies","nombreHobby",hobbie.trim().toLowerCase());
                    if(idHobbies != -1){
                        estamento.setInt(1, idAlumno);
                        estamento.setInt(2, idHobbies);
                        estamento.executeUpdate();

                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }finally {
            try {
                estamento.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private List<String> estudiosLista(){
        List<String> estudios = new ArrayList<>();
        estudios.add("ESO");
        estudios.add("Bachillerato");
        estudios.add("FP Básica");
        estudios.add("Ciclo FP grado medio");
        estudios.add("Ciclo FP grado superior");
        estudios.add("Otros");
        return estudios;
    }
    private List<String> hobbiesLista(){
        List<String> hobbies = new ArrayList<>();
        hobbies.add("Leer libros");
        hobbies.add("Practicar deportes (menciona deportes específicos)");
        hobbies.add("Hacer ejercicio");
        hobbies.add("Pintura o dibujo");
        hobbies.add("Música (tocar un instrumento musical o escuchar música)");
        hobbies.add("Cocinar o hornear");
        hobbies.add("Jardinería");
        hobbies.add("Fotografía");
        hobbies.add("Juegos de mesa");
        hobbies.add("Videojuegos");
        hobbies.add("Ver películas o series");
        hobbies.add("Coleccionar");
        hobbies.add("Senderismo o actividades al aire libre");
        hobbies.add("Voluntariado-actividades beneficiarias");
        hobbies.add("Otros");
        return hobbies;
    }
    private int obtenerId(String id, String tabla, String nombreColumna, String busqueda) {
        String consultaSql = "SELECT " +id+ " FROM " + tabla +  " WHERE "  + nombreColumna + " = ?";
        int devolver = 0;
        ResultSet resultado = null;
        try (PreparedStatement consulta = conexion.prepareStatement(consultaSql)) {
            consulta.setString(1, busqueda);
            resultado = consulta.executeQuery();

            if (resultado.next()) {
                devolver = resultado.getInt(1);
            } else {
                devolver = -1;
            }
        } catch (SQLException e) {
            System.err.println("Error en la consulta para obtener id de estudio: " + e.getMessage());
            devolver = -1;
        }finally {
            try {
                resultado.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return devolver;
    }
    private void crearTablas(){
        crearTablas("Estudios",
                "idEstudio NUMBER primary key,"+
                        "nombreEstudio VARCHAR2(100)"
        );
        crearTablas("Hobbies",
                "idHobby NUMBER PRIMARY KEY,"+
                        "nombreHobby VARCHAR2(100)"
        );
        crearTablas("Alumnos",
                "id NUMBER primary key,"+
                        "nombre VARCHAR2(100)," +
                        "apellidos VARCHAR2(100),"+
                        "email VARCHAR2(100),"+"poblacion VARCHAR2(100),"+"telefono VARCHAR2(100),"+
                        "ciclo VARCHAR2(100)," + "ordenador VARCHAR2(100)," + "siCarnet VARCHAR2(10)," +
                        "fechNac DATE," + "motivacion VARCHAR2(100)"
        );
        crearTablas("AlumnosEstudios",
                "idAlumno NUMBER,"+
                        "idEstudio NUMBER,"+
                        "FOREIGN KEY (idAlumno) REFERENCES Alumnos(id),"+
                        "FOREIGN KEY (idEstudio) REFERENCES Estudios(idEstudio)"
        );
        crearTablas("AlumnosHobbies",
                "idAlumno NUMBER,"+
                        "idHobby NUMBER,"+
                        "FOREIGN KEY (idAlumno) REFERENCES Alumnos(id),"+
                        "FOREIGN KEY (idHobby) REFERENCES Hobbies(idHobby)"
        );
        insertarDatosAlumnos();
        insertarDatosEstudios();
        insertarDatosHobbies();
        insertarAlumnosEstudios();
        insertarAlumnosHobbies();
    }

    public Connection getConexion() {
        return conexion;
    }
}
