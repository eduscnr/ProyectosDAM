package org.example.basededatos;

import org.example.modelo.Alumno;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AlumnoDAOImpl implements AlumnoDAO{
    private Connection conexion;

    public AlumnoDAOImpl(Connection conexion) {
        this.conexion = conexion;
    }
    @Override
    public List<String> recuperarEstudiosPorAlumno(int idAlumno) {
        List<String> estudios = new ArrayList<>();
        String sentenciaSql = "SELECT E.nombreEstudio " +
                "FROM AlumnosEstudios AE " +
                "INNER JOIN Estudios E ON AE.idEstudio = E.idEstudio " +
                "WHERE AE.idAlumno = ?";
        PreparedStatement estamento = null;
        ResultSet resultado = null;
        try {
            estamento = conexion.prepareStatement(sentenciaSql);
            estamento.setInt(1, idAlumno);
            resultado = estamento.executeQuery();
            while(resultado.next()){
                String estudio = resultado.getString("nombreEstudio");
                estudios.add(estudio);
            }
        } catch (SQLException e) {
            System.out.println(e.getErrorCode() + " " + e.getMessage());
        }finally {
            try {
                estamento.close();
                resultado.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return estudios;
    }

    @Override
    public void eliminarAlumno(int idAlumno) {
        String sql = "DELETE FROM Alumnos WHERE id = ?";
        PreparedStatement preparedStatement = null;
        try {
            eliminarEstudiosDelAlumno(idAlumno);
            eliminarHobbiesDelAlumno(idAlumno);
            preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setInt(1, idAlumno);
            preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alumno eliminado exitosamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El alumno no se ha podido eliminar. Codigo del error: " + e.getErrorCode(), "Error", JOptionPane.ERROR_MESSAGE);
        }finally {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void actualizarAlumno(Alumno alumno) {
        String sqlAlumno = "UPDATE Alumnos SET nombre = ?, apellidos = ?, email = ?, poblacion = ?, telefono = ?, ciclo = ?, ordenador = ?, siCarnet = ?, fechNac = ?, motivacion = ? WHERE id = ?";
        PreparedStatement updateAlumno = null;
        try {
            updateAlumno = conexion.prepareStatement(sqlAlumno);
            updateAlumno.setString(1, alumno.getNombre());
            updateAlumno.setString(2, alumno.getApellido());
            updateAlumno.setString(3, alumno.getEmail());
            updateAlumno.setString(4, alumno.getPoblacion());
            updateAlumno.setString(5, alumno.getTelefono());
            updateAlumno.setString(6, alumno.getCiclo().toString());
            updateAlumno.setString(7, alumno.getOrdenador().toString());
            if(alumno.isSiCarnet()){
                updateAlumno.setString(8, "si");
            }else{
                updateAlumno.setString(8, "no");
            }
            updateAlumno.setDate(9, new java.sql.Date(alumno.getFechNac().getTime()));
            updateAlumno.setString(10, alumno.getMotivacion().toString());
            updateAlumno.setInt(11, alumno.getId());
            updateAlumno.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al realizar la actualizacion de alumno. Codigo " + e.getErrorCode(), "Error", JOptionPane.ERROR_MESSAGE);
        }finally {
            try {
                updateAlumno.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        List<Integer> idEstudios = new ArrayList<>();
        for (String nombreEstudio : alumno.getEstudios()) {
            int idEstudio = obtenerEstudioId(nombreEstudio);
            if (idEstudio != -1) {
                idEstudios.add(idEstudio);
            }
        }
        String sqlEliminarEstudios = "DELETE FROM AlumnosEstudios WHERE idAlumno = ?";
        PreparedStatement statementEliminarEstudios = null;
        try {
            statementEliminarEstudios = conexion.prepareStatement(sqlEliminarEstudios);
            statementEliminarEstudios.setInt(1, alumno.getId());
            statementEliminarEstudios.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar relaciones con estudios. Codigo " + e.getErrorCode(), "Error", JOptionPane.ERROR_MESSAGE);
        }finally{
            try {
                statementEliminarEstudios.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        String sqlInsertarEstudios = "INSERT INTO AlumnosEstudios (idAlumno, idEstudio) VALUES (?, ?)";
        for (int idEstudio : idEstudios) {
            PreparedStatement statementInsertarEstudios = null;
            try {
                statementInsertarEstudios = conexion.prepareStatement(sqlInsertarEstudios);
                statementInsertarEstudios.setInt(1, alumno.getId());
                statementInsertarEstudios.setInt(2, idEstudio);
                statementInsertarEstudios.executeUpdate();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al insertar relaciones con estudios. Codigo " + e.getErrorCode(), "Error", JOptionPane.ERROR_MESSAGE);
            }finally {
                try {
                    statementInsertarEstudios.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        List<Integer> idHobbies = new ArrayList<>();
        for (String nombreHobbie : alumno.getHobbies()) {
            int idHobbie = obtenerIdHobbieDesdeNombre(nombreHobbie);
            if (idHobbie != -1) {
                idHobbies.add(idHobbie);
            }
        }
        String eliminarHobbies = "DELETE FROM AlumnosHobbies WHERE idAlumno = ?";
        PreparedStatement stamentoHobbies = null;
        try {
            stamentoHobbies = conexion.prepareStatement(eliminarHobbies);
            stamentoHobbies.setInt(1, alumno.getId());
            stamentoHobbies.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en eliminar alumnosHobbies. Codigo " + e.getErrorCode(), "Error", JOptionPane.ERROR_MESSAGE);
        }finally{
            try {
                stamentoHobbies.close();
            } catch (SQLException e) {

            }
        }
        String insertarNuevoHobbies = "INSERT INTO AlumnosHobbies (idAlumno, idHobby) VALUES (?, ?)";
        for (int idHobbie : idHobbies) {
            PreparedStatement statementInsertarHobbie = null;
            try {
                statementInsertarHobbie = conexion.prepareStatement(insertarNuevoHobbies);
                statementInsertarHobbie.setInt(1, alumno.getId());
                statementInsertarHobbie.setInt(2, idHobbie);
                statementInsertarHobbie.executeUpdate();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al insertar relaciones con hobbies: " + e.getErrorCode(), "Error", JOptionPane.ERROR_MESSAGE);
            }finally{
                try {
                    stamentoHobbies.close();
                } catch (SQLException e) {

                }
            }
        }
        JOptionPane.showMessageDialog(null, "Alumno se ha actualizado exitosamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void nuevoAlumno(Alumno alumno) {
        String sqlAlumno = "INSERT INTO Alumnos VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement insertAlumno = null;
        String ultimoIdSelect = "SELECT MAX(id) FROM Alumnos";
        int idAlumno = 0;
        try {
            PreparedStatement ultimoIdStamento = null;
            ultimoIdStamento = conexion.prepareStatement(ultimoIdSelect);
            ResultSet resultado = ultimoIdStamento.executeQuery();
            if(resultado.next()){
                idAlumno = resultado.getInt(1);
            }
            insertAlumno = conexion.prepareStatement(sqlAlumno);
            insertAlumno.setInt(1, idAlumno+1);
            insertAlumno.setString(2, alumno.getNombre());
            insertAlumno.setString(3, alumno.getApellido());
            insertAlumno.setString(4, alumno.getEmail());
            insertAlumno.setString(5, alumno.getPoblacion());
            insertAlumno.setString(6, alumno.getTelefono());
            insertAlumno.setString(7, alumno.getCiclo().toString());
            insertAlumno.setString(8, alumno.getOrdenador().toString());
            if (alumno.isSiCarnet()) {
                insertAlumno.setString(9, "si");
            } else {
                insertAlumno.setString(9, "no");
            }
            insertAlumno.setDate(10, new java.sql.Date(alumno.getFechNac().getTime()));
            insertAlumno.setString(11, alumno.getMotivacion().toString());
            int filaAfectada = insertAlumno.executeUpdate();
            if(filaAfectada == 0) {
                JOptionPane.showMessageDialog(null, "La inserción del alumno falló, no se agregaron registros.");
            }
            insertarEstudiosDelAlumno(idAlumno+1, alumno.getEstudios());
            insertarHobbiesDelAlumno(idAlumno+1, alumno.getHobbies());
            JOptionPane.showMessageDialog(null, "Usuario creado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Usuario creado correctamente. Codigo del error: " + e.getErrorCode(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public List<String> recuperarHobbiesPorAlumno(int idAlumno) {
        List<String> hobbies = new ArrayList<>();
        String senctenciaSql = "SELECT H.nombreHobby FROM AlumnosHobbies AH " +
                "INNER JOIN Hobbies H ON AH.idHobby = H.idHobby " +
                "WHERE AH.idAlumno = ?";
        PreparedStatement estamento = null;
        ResultSet resultado = null;
        try {
            estamento = conexion.prepareStatement(senctenciaSql);
            estamento.setInt(1, idAlumno);
            resultado = estamento.executeQuery();
            while(resultado.next()){
                String hobbie = resultado.getString("nombreHobby");
                hobbies.add(hobbie);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                estamento.close();
                resultado.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return hobbies;
    }
    private int obtenerEstudioId(String nombreEstudio){
        String sql = "SELECT idEstudio FROM Estudios WHERE nombreEstudio = ?";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            statement = conexion.prepareStatement(sql);
            statement.setString(1, nombreEstudio);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("idEstudio");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            try {
                statement.close();
                resultSet.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return -1;
    }
    private int obtenerIdHobbieDesdeNombre(String nombreHobbie) {
        String sql = "SELECT idHobby FROM Hobbies WHERE nombreHobby = ?";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            statement = conexion.prepareStatement(sql);
            statement.setString(1, nombreHobbie);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("idHobby");
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener ID del hobbie: " + e.getMessage());
        }finally{
            try {
                statement.close();
                resultSet.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return -1;
    }
    private void insertarEstudiosDelAlumno(int idAlumno, List<String> estudios) {
        String sqlInsertEstudio = "INSERT INTO AlumnosEstudios (idAlumno, idEstudio) VALUES (?, ?)";
        PreparedStatement insertEstudio = null;

        try {
            insertEstudio = conexion.prepareStatement(sqlInsertEstudio);
            for (String nombreEstudio : estudios) {
                int idEstudio = obtenerEstudioId(nombreEstudio);
                if (idEstudio != -1) {
                    insertEstudio.setInt(1, idAlumno);
                    insertEstudio.setInt(2, idEstudio);
                    insertEstudio.executeUpdate();
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar estudios del alumno: " + e.getMessage());
        }finally {
            try {
                insertEstudio.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void insertarHobbiesDelAlumno(int idAlumno, List<String> hobbies) {
        String sqlInsertHobbie = "INSERT INTO AlumnosHobbies (idAlumno, idHobby) VALUES (?, ?)";
        PreparedStatement insertHobbie = null;
        try {
            insertHobbie = conexion.prepareStatement(sqlInsertHobbie);
            for (String nombreHobbie : hobbies) {
                int idHobbie = obtenerIdHobbieDesdeNombre(nombreHobbie);
                if (idHobbie != -1) {
                    insertHobbie.setInt(1, idAlumno);
                    insertHobbie.setInt(2, idHobbie);
                    insertHobbie.executeUpdate();
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar hobbies del alumno: " + e.getMessage());
        }finally {
            try {
                insertHobbie.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    private void eliminarHobbiesDelAlumno(int idAlumno){
        PreparedStatement deleteEstudiosStmt = null;
        try {
            String deleteEstudiosSQL = "DELETE FROM AlumnosHobbies WHERE idAlumno= ?";
            deleteEstudiosStmt = conexion.prepareStatement(deleteEstudiosSQL);
            deleteEstudiosStmt.setInt(1, idAlumno);
            deleteEstudiosStmt.executeUpdate();
            deleteEstudiosStmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                deleteEstudiosStmt.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    private void eliminarEstudiosDelAlumno(int idAlumno){
        PreparedStatement deleteHobbiesStmt = null;
        try {
            String deleteHobbiesSQL = "DELETE FROM AlumnosEstudios WHERE idAlumno = ?";
            deleteHobbiesStmt = conexion.prepareStatement(deleteHobbiesSQL);
            deleteHobbiesStmt.setInt(1, idAlumno);
            deleteHobbiesStmt.executeUpdate();
            deleteHobbiesStmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                deleteHobbiesStmt.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
