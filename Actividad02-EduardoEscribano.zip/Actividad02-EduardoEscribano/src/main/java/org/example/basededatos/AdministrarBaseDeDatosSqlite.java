package org.example.basededatos;

import org.example.json.LeerJson;
import org.example.modelo.Alumno;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdministrarBaseDeDatosSqlite {
    private Connection conexion;
    private File ruta;

    public Connection getConexion() {
        return conexion;
    }

    public AdministrarBaseDeDatosSqlite(File ruta) {
        if(!ruta.exists()){
            conexion= creacionBaseDeDatos(ruta);
            crearBaseDeDatos();
        }else{
            conexion = creacionBaseDeDatos(ruta);
        }
    }

    public Connection creacionBaseDeDatos(File ruta){
        Connection connection = null;
        String url = "jdbc:sqlite:"+ruta.toString();
        try {
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.err.println("Error al crear la base de datos: " + e.getMessage());
        }
        return connection;
    }
    public void cerrarConexion(){
        if(conexion != null){
            try {
                conexion.close();
                System.out.println("Conexión cerrada con exito");
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public void crearTablas(String nombreTabla, String estructuraTabla){
        try {
            Statement statement = conexion.createStatement();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS " + nombreTabla + " (" + estructuraTabla + ")";
            statement.executeUpdate(createTableSQL);
            statement.close();
            System.out.println("Tabla " + nombreTabla + " creada con éxito.");
        } catch (SQLException e) {
            System.err.println("Error al crear la tabla: " + e.getMessage());
        }
    }
    public void insertarDatosAlumnos() {
        String sentenciaSql = "INSERT INTO Alumnos VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        List<Alumno> alumnos = LeerJson.recuperarDatos("ficheros/alumnos.json");
        long tiempo = 0;
        Timestamp sqlTimestamp = null;
        Date sqlDate = null;
        try {
            PreparedStatement estamento = conexion.prepareStatement(sentenciaSql);
           for (Alumno alumno : alumnos) {
                estamento.setInt(1, alumno.getId());
                estamento.setString(2, alumno.getNombre());
                estamento.setString(3, alumno.getApellido());
                estamento.setString(4, alumno.getEmail());
                estamento.setString(5, alumno.getPoblacion());
                estamento.setString(6, alumno.getTelefono());
                estamento.setString(7, alumno.getCiclo().toString());
                estamento.setString(8, alumno.getOrdenador().toString());
                if (alumno.isSiCarnet()) {
                    estamento.setString(9, "Si");
                } else {
                    estamento.setString(9, "No");
                }
                tiempo = alumno.getFechNac().getTime();
                sqlTimestamp = new Timestamp(tiempo);
                estamento.setTimestamp(10, sqlTimestamp);
                estamento.setString(11, alumno.getMotivacion().toString());
                estamento.execute();
            }
        } catch (SQLException e) {
            System.err.println("Error en la inserción de datos en la tabla Alumnos: " + e.getErrorCode());
        }
    }

    public void insertarDatosEstudios(){
        String sentenciaSql = "INSERT INTO Estudios VALUES (?,?)";
        List<String> estudios = estudiosLista();
        int id = 1;
        try {
            PreparedStatement estamento = conexion.prepareStatement(sentenciaSql);
            for(String estudio : estudios){
                estamento.setInt(1, id);
                estamento.setString(2, estudio);
                estamento.execute();
                id++;
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }
    }
    public void insertarDatosHobbies(){
        String sentenciaSql = "INSERT INTO Hobbies VALUES (?,?)";
        List<String> hobbies = hobbiesLista();
        int id = 1;
        try {
            PreparedStatement estamento = conexion.prepareStatement(sentenciaSql);
            for(String hobbis : hobbies){
                estamento.setInt(1, id);
                estamento.setString(2, hobbis.toLowerCase());
                estamento.execute();
                id++;
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }
    }
    public void insertarAlumnosEstudios(){
        String sentenciaSql = "INSERT INTO AlumnosEstudios VALUES (?,?)";
        int idEstudio, idAlumno;
        try {
            PreparedStatement estamento = conexion.prepareStatement(sentenciaSql);
            List<Alumno> alumnos = LeerJson.recuperarDatos("ficheros/alumnos.json");
            for (Alumno alumno : alumnos){
                idAlumno = alumno.getId();
                for (String estudio : alumno.getEstudios()){
                    idEstudio = obtenerId("idEstudio","Estudios","nombreEstudio",estudio.trim());
                    if(idEstudio != -1){
                        estamento.setInt(1, idAlumno);
                        estamento.setInt(2, idEstudio);
                        estamento.executeUpdate();
                        System.out.println("Relación entre alumno " + idAlumno + " y estudio " + idEstudio + " insertada.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }
    }
    public void insertarAlumnosHobbies(){
        String sentenciaSql = "INSERT INTO AlumnosHobbies VALUES (?,?)";
        int idHobbies, idAlumno;
        try {
            PreparedStatement estamento = conexion.prepareStatement(sentenciaSql);
            List<Alumno> alumnos = LeerJson.recuperarDatos("ficheros/alumnos.json");
            for (Alumno alumno : alumnos){
                idAlumno = alumno.getId();
                for (String hobbie : alumno.getHobbies()){
                    idHobbies = obtenerId("idHobby","Hobbies","nombreHobby",hobbie.trim().toLowerCase());
                    if(idHobbies != -1){
                        estamento.setInt(1, idAlumno);
                        estamento.setInt(2, idHobbies);
                        estamento.executeUpdate();
                        System.out.println("Relación entre alumno " + idAlumno + " y hobbies " + idHobbies + " insertada.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error en la insercion de datos en tabla estudios " + e.getErrorCode());
        }
    }

    private List<String> estudiosLista(){
        List<String> estudios = new ArrayList<>();
        estudios.add("ESO");
        estudios.add("Bachillerato");
        estudios.add("FP Básica");
        estudios.add("Ciclo FP grado medio");
        estudios.add("Ciclo FP grado superior");
        estudios.add("Otros");
        return estudios;
    }
    private List<String> hobbiesLista(){
        List<String> hobbies = new ArrayList<>();
        hobbies.add("Leer libros");
        hobbies.add("Practicar deportes (menciona deportes específicos)");
        hobbies.add("Hacer ejercicio");
        hobbies.add("Pintura o dibujo");
        hobbies.add("Música (tocar un instrumento musical o escuchar música)");
        hobbies.add("Cocinar o hornear");
        hobbies.add("Jardinería");
        hobbies.add("Fotografía");
        hobbies.add("Juegos de mesa");
        hobbies.add("Videojuegos");
        hobbies.add("Ver películas o series");
        hobbies.add("Coleccionar");
        hobbies.add("Senderismo o actividades al aire libre");
        hobbies.add("Voluntariado-actividades beneficiarias");
        hobbies.add("Otros");
        return hobbies;
    }
    private int obtenerId(String id, String tabla, String nombreColumna, String busqueda) {
        String consultaSql = "SELECT " +id+ " FROM " + tabla +  " WHERE "  + nombreColumna + " = ?";
        int devolver = 0;
        try (PreparedStatement consulta = conexion.prepareStatement(consultaSql)) {
            consulta.setString(1, busqueda);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                devolver = resultado.getInt(1);
            } else {
                devolver = -1;
            }
        } catch (SQLException e) {
            System.err.println("Error en la consulta para obtener id de estudio: " + e.getMessage());
            devolver = -1;
        }
        return devolver;
    }
    private void crearBaseDeDatos(){
        crearTablas("Estudios",
                "idEstudio int primary key,"+
                        "nombreEstudio varchar(50)"
        );
        crearTablas("Hobbies",
                "idHobby int PRIMARY KEY,"+
                        "nombreHobby varchar(50)"
        );
        crearTablas("Alumnos",
                "id INTEGER primary key,"+
                        "nombre varchar(100)," +
                        "apellidos varchar(100),"+
                        "email varchar(50),"+"poblacion varchar(50),"+"telefono varchar(10),"+
                        "ciclo varchar(20)," + "ordenador varchar(10)," + "siCarnet varchar(2)," +
                        "fechNac date," + "motivacion varchar(20)"
        );
        crearTablas("AlumnosEstudios",
                "idAlumno int,"+
                        "idEstudio int,"+
                        "FOREIGN KEY (idAlumno) REFERENCES Alumnos(id),"+
                        "FOREIGN KEY (idEstudio) REFERENCES Estudios(idEstudio)"
        );
        crearTablas("AlumnosHobbies",
                "idAlumno int,"+
                        "idHobby int,"+
                        "FOREIGN KEY (idAlumno) REFERENCES Alumnos(id),"+
                        "FOREIGN KEY (idHobby) REFERENCES Hobbies(idHobby)"
        );
        insertarDatosAlumnos();
        insertarDatosEstudios();
        insertarDatosHobbies();
        insertarAlumnosEstudios();
        insertarAlumnosHobbies();
        try {
            conexion.createStatement().execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
