package es.bosco.probarDAO;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import es.bosco.repositorio.DepartamentoDAOJDBC;
import es.bosco.repositorio.DepartamentoDAOJDBCImpl;

import java.sql.SQLException;

public class pruebaJDBC {
    public static void main(String[] args) throws SQLException {
        DepartamentoDAOJDBC departamentoDAOJDBC = new DepartamentoDAOJDBCImpl();
        /*Departamento d = new Departamento(156L, "PosiblePrueba6", "Toledo");
        Empleado e1 = new Empleado(83, "Nose", 4500);
        Empleado e2 = new Empleado(84, "Nose1", 4500);
        d.getEmpleados().add(e1);
        d.getEmpleados().add(e2);
        boolean t =  departamentoDAOJDBC.crearDepartamento(d);
        System.out.println(t);*/
        departamentoDAOJDBC.allDepartamento();
    }
}
