package es.bosco.probarDAO;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import es.bosco.repositorio.EmpleadoDAO;
import es.bosco.repositorio.EmpleadoDAOImple;

import java.util.logging.Level;
import java.util.logging.Logger;

public class pruebaDAOEmple {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        EmpleadoDAO  empleadoDAO = new EmpleadoDAOImple("upEduardo");
        Empleado e = new Empleado(500,"Eduardo", 3552);
        Departamento d = new Departamento(96L, "Nuevo2", "TOMELLOSO");
        e.setDepartamento(d);
        empleadoDAO.updateOrCreateEmpleado(e);
    }
}
