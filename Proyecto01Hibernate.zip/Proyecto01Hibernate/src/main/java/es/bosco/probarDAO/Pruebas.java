package es.bosco.probarDAO;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import es.bosco.repositorio.DepartamentoDAO;
import es.bosco.repositorio.DepartamentoDAOImple;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Pruebas {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        DepartamentoDAO departamentoDAO = new DepartamentoDAOImple("upEduardo");
        System.out.println("DEPARTAMENTO");
        System.out.println(departamentoDAO.getDepartamento(100L));
        System.out.println("LISTA DEPARTAMENTOS");
        System.out.println("-----------------------------------------");
        List<Departamento> listD = departamentoDAO.getAllDepartamento();
        listD.forEach(d ->{
            System.out.println(d.getNombre());
        });
        System.out.println("-----------------------------------------");
        Departamento depNuevo = new Departamento(90L, "Nuevo", "TOMELLOSO");
        Empleado eNuevo1 = new Empleado(100, "MANOLO", 3000);
        Empleado eNuevo2 = new Empleado(101, "MANOLA", 2999);
        depNuevo.addEmpleado(eNuevo1);
        depNuevo.addEmpleado(eNuevo2);
        /*if(departamentoDAO.aniadirEmpleado(depNuevo)){
            System.out.println("Departamento insertado correctamente, con sus empleados");
        }else{
            System.out.println("Mala suerte, vuelve a intentarlo jajaja");
        }*/
        Empleado e3 = new Empleado(103, "MANOLI", 3000);
        depNuevo.addEmpleado(e3);
        if(departamentoDAO.updateOrCreateDepartamento(depNuevo)){
            System.out.println("Actualizado con exito :)");
        }else{
            System.out.println("No se ha actualizado :(");
        }
        Departamento depNuevo2 = new Departamento(98L, "Nuevo DEPT22222", "Villafranca de los caballero");
        Empleado e21 = new Empleado(105, "PEPE", 3000);
        Empleado e22 = new Empleado(106, "PEPA", 3000);
        depNuevo2.addEmpleado(e21);
        depNuevo2.addEmpleado(e22);
        departamentoDAO.updateOrCreateDepartamento(depNuevo2);
    }
}
