package es.bosco.probarDAO;

import es.bosco.repositorio.DepartamentoDAO;
import es.bosco.repositorio.DepartamentoDAOImple;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Pruebas {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        DepartamentoDAO departamentoDAO = new DepartamentoDAOImple("upEduardo");
        System.out.println(departamentoDAO.getDepartamento(10L));
    }
}
