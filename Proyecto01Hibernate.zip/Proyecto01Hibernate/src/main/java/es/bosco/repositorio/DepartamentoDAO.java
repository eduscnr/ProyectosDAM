package es.bosco.repositorio;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;

import java.util.List;

/**
 * Interfaz del operaciones del Departamento
 */
public interface DepartamentoDAO {
    //CRUD

    /**
     * Añadir un departamento con empleados
     * @param departamento departamento a añadir
     * @return true si ha tenido éxito
     */
    public boolean aniadirEmpleado(Departamento departamento);

    /**
     * Elimina un departameto a partir de su id
     * @param idDepartamento id del departamento a eliminar
     * @return true si ha tenido éxito
     */
    public boolean borrarDepartamento(Long idDepartamento);
    /**
     * Elimina un departameto a partir de su nombre del departamento
     * @param nombreDepartamento nombre del departamento a eliminar
     * @return true si ha tenido éxito
     */
    public boolean borrarDepartamento(String nombreDepartamento);

    /**
     * Actualizar el antiguo departamento por el nuevo Departamento o los crea si no exite
     * @param departamentoNuevo el nuevo departamento a actualizar
     * @return true si se ha tenido éxito
     */
    public boolean updateOrCreateDepartamento(Departamento departamentoNuevo);

    /**
     * Obtiene un departamento a partir de su nombre
     * @param nombreDepartamento nombre del departamento a buscar
     * @return devuelve el departamento que se ha buscado
     */
    public Departamento getDepartamento(String nombreDepartamento);

    /**
     * Obtiene un departamento a partir de su id
     * @param idDepartamento id del departamento a buscar
     * @return devuelve el departamento que se ha buscado
     */
    public Departamento getDepartamento(Long idDepartamento);

    /**
     * Obtiene una lista de los empleado a partir del nombre del departamento
     * @param nombreDepartameto nombre del departamento a buscar
     * @return devuelve una lista con los empleado de ese departmento
     */
    public List<Empleado> listaEmpleado(String nombreDepartameto);
    /**
     * Obtiene una lista de los empleado a partir del id del departamento
     * @param idDepartemento id del departamento a buscar
     * @return devuelve una lista con los empleado de ese departmento
     */
    public List<Empleado> listaEmpleado(Long idDepartemento);

    /**
     * Lista de todos los departamentos
     * @return devuelve todos los departamente existentes
     */
    public List<Departamento> getAllDepartamento();
}
