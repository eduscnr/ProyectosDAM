package es.bosco.repositorio;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;

public interface EmpleadoDAO {
    public boolean aniadirEmpleado(Empleado newEmpl);
    public boolean borrarEmpl(String nameEmpl);
    public boolean updateOrCreateEmpleado(Empleado empleado);
}
