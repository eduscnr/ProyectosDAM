package es.bosco.repositorio;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartamentoDAOJDBCImpl implements DepartamentoDAOJDBC{
    private final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private final String user = "EDUARDO2";
    private final String contrasenia = "1234";
    private Connection conexion;

    public DepartamentoDAOJDBCImpl() throws SQLException {
        conexion = DriverManager.getConnection(URL, user, contrasenia);
    }

    @Override
    public boolean crearDepartamento(Departamento departamentoNuevo) {
        String insert = "INSERT INTO Departamento (idDep, nombre, loc) values (?,?,?)";
        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(insert);
            preparedStatement.setLong(1, departamentoNuevo.getIdDep());
            preparedStatement.setString(2, departamentoNuevo.getNombre());
            preparedStatement.setString(3, departamentoNuevo.getLoc());
            preparedStatement.executeQuery();
        } catch (SQLException e) {
            System.out.println(e.getErrorCode());
            return false;
        }
        if(!departamentoNuevo.getEmpleados().isEmpty()){
            for (Empleado em: departamentoNuevo.getEmpleados()){
                insert = "INSERT INTO EMPLEADOS (id_Emp, nombre, sueldo, ID_DEPT) values (?, ?, ?, ?)";
                try {
                    PreparedStatement preparedStatement = conexion.prepareStatement(insert);
                    preparedStatement.setLong(1, em.getIdEmp());
                    preparedStatement.setString(2, em.getNombre());
                    preparedStatement.setFloat(3,em.getSueldo());
                    preparedStatement.setLong(4, departamentoNuevo.getIdDep());
                    preparedStatement.executeQuery();
                } catch (SQLException e) {
                    return false;
                }
            }
        }

        return true;
    }

    @Override
    public void allDepartamento() {
        String select = "Select * from departamento";
        List<Departamento> listD = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(select);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                Departamento d = new Departamento(resultSet.getLong("IDDEP"), resultSet.getString("NOMBRE"), resultSet.getString("LOC"));
                listD.add(d);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        for (Departamento d: listD){
            cargarEmpleadoEnDepartamento(d);
        }
        for (Departamento d: listD){
            for (Empleado empleado : d.getEmpleados()){
                if(!d.getEmpleados().isEmpty()){
                    System.out.println(empleado);
                }
            }
        }
        System.out.println(listD);
    }
    private void cargarEmpleadoEnDepartamento(Departamento d){
        String select1 = "Select e.id_emp, e.nombre, e.sueldo FROM DEPARTAMENTO d INNER JOIN EMPLEADOS e " +
                "ON d.IDDEP = e.ID_DEPT " +
                "WHERE d.IDDEP = ?";
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = conexion.prepareStatement(select1);
            preparedStatement.setLong(1, d.getIdDep());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                Empleado e = new Empleado(resultSet.getInt("ID_EMP"), resultSet.getString("NOMBRE"), resultSet.getFloat("SUELDO"));
                e.setDepartamento(d);
                d.getEmpleados().add(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
