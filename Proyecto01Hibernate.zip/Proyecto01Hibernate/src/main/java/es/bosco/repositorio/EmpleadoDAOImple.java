package es.bosco.repositorio;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class EmpleadoDAOImple implements EmpleadoDAO{
    EntityManager em;
    public EmpleadoDAOImple(String up) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(up);
        this.em = emf.createEntityManager();
    }
    @Override
    public boolean aniadirEmpleado(Empleado newEmpl) {
        boolean devolver = false;
        try{
            em.getTransaction().begin();
            em.persist(newEmpl);
            em.getTransaction().commit();
            devolver = true;
        }catch (Exception cve){
            devolver = false;
        }
        return devolver;
    }

    @Override
    public boolean borrarEmpl(String nameEmpl) {
        boolean devolver = false;
        String hql = "from Empleado e where e.nombre = :pEmp";
        Empleado empleado = (Empleado) em.createQuery(hql).setParameter("pEmp",nameEmpl).getSingleResult();
        if(empleado != null){
            try{
                em.getTransaction().begin();
                em.remove(empleado);
                em.getTransaction().commit();
                devolver = true;
            }catch (Exception ex){
                devolver = false;
            }
        }
        return devolver;
    }

    @Override
    public boolean updateOrCreateEmpleado(Empleado empleado) {
        em.getTransaction().begin();
        em.merge(empleado);
        em.getTransaction().commit();
        return true;
    }
}
