package es.bosco.repositorio;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.validation.ConstraintViolationException;

import java.util.List;

public class DepartamentoDAOImple implements DepartamentoDAO {
    EntityManager em;
    public DepartamentoDAOImple(String up) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(up);
        this.em = emf.createEntityManager();
    }

    @Override
    public boolean aniadirEmpleado(Departamento departamento) {
        boolean devolver = false;
        try{
            em.getTransaction().begin();
            em.persist(departamento);
            em.getTransaction().commit();
            devolver = true;
        }catch (Exception cve){
            devolver = false;
        }
        return devolver;
    }

    @Override
    public boolean borrarDepartamento(Long idDepartamento) {
        boolean devolver = false;
        Departamento departamentoEliminar = em.find(Departamento.class, idDepartamento);
        if(departamentoEliminar != null){
            try{
                em.getTransaction().begin();
                em.remove(departamentoEliminar);
                em.getTransaction().commit();
                devolver = true;
            }catch (Exception ex){
                devolver = false;
            }
        }
        return devolver;
    }
    @Override
    public boolean borrarDepartamento(String nombreDepartamento) {
        boolean devolver = false;
        String hql = "from Departamento d where d.nombre = :pNom";
        Departamento departamentoEliminar = (Departamento) em.createQuery(hql).setParameter("pNom",nombreDepartamento).getSingleResult();
        if(departamentoEliminar != null){
            try{
                em.getTransaction().begin();
                em.remove(departamentoEliminar);
                em.getTransaction().commit();
                devolver = true;
            }catch (Exception ex){
                devolver = false;
            }
        }
        return devolver;
    }

    @Override
    public boolean updateOrCreateDepartamento(Departamento departamentoNuevo) {
        em.getTransaction().begin();
        em.merge(departamentoNuevo);
        em.getTransaction().commit();
        return true;
    }

    @Override
    public Departamento getDepartamento(String nombreDepartamento) {
        String hql = "from Departamento d where d.nombre = :pNom";
        return (Departamento) em.createQuery(hql).setParameter("pNom", nombreDepartamento).getSingleResult();
    }

    @Override
    public Departamento getDepartamento(Long idDepartamento) {
        return em.find(Departamento.class, idDepartamento);
    }

    @Override
    public List<Empleado> listaEmpleado(String nombreDepartameto) {
        String hql = "from Departamento d where d.nombre = :pNom";
        Departamento dep = (Departamento) em.createQuery(hql).setParameter("pNom", nombreDepartameto).getResultList();
        return dep.getEmpleados();
    }

    @Override
    public List<Empleado> listaEmpleado(Long idDepartemento) {
        Departamento dep = em.find(Departamento.class, idDepartemento);
        return dep.getEmpleados();
    }

    @Override
    public List<Departamento> getAllDepartamento() {
        return em.createQuery("from Departamento d").getResultList();
    }
}
