package es.bosco.repositorio;

import es.bosco.modelo.Departamento;

public interface DepartamentoDAOJDBC {
    public boolean crearDepartamento(Departamento departamentoNuevo);
    public void allDepartamento();
}
