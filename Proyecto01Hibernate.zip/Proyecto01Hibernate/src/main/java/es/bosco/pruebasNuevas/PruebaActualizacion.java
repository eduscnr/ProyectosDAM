package es.bosco.pruebasNuevas;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PruebaActualizacion {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //1. Obtener un manejador de entidades
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        Departamento d = em.find(Departamento.class, 1L);
        Calendar calendar = Calendar.getInstance();

        calendar.set(2004, 3, 16);
        Empleado e1 = new Empleado(3, "LUIS-JO", 1, calendar.getTime());
        em.getTransaction().begin();
        d.addEmpleado(e1);
        //d.addEmpleado(e1); //puede usar esto para añadir a un empleado en un departamente sin necesidad de usar merge
        em.merge(e1);
        em.getTransaction().commit();
    }
}
