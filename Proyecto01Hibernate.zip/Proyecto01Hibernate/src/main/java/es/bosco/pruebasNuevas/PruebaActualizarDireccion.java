package es.bosco.pruebasNuevas;

import es.bosco.modelo.Direccion;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PruebaActualizarDireccion {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //1. Obtener un manejador de entidades
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        Empleado e1 = em.find(Empleado.class, 1);
        Direccion dire1 = new Direccion(1L, "TOMELLOSO", "La Paz", "13700", e1);
        em.getTransaction().begin();
        e1.addDireccion(dire1);
        em.merge(e1);
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
}
