package es.bosco.pruebasNuevas;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PruebaInsercion {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //1. Obtener un manejador de entidades
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        Departamento d1 = new Departamento(1L, "INFORMÁTICA", "TOMELLOSO");
        Calendar calendar = Calendar.getInstance();

        calendar.set(2003, 4, 8);
        Empleado e1 = new Empleado(1, "JAVIER", 3000, calendar.getTime());
        calendar.set(2004, 5, 4);
        Empleado e2 = new Empleado(2, "TERESA", 3500, calendar.getTime());

        d1.addEmpleado(e1);
        d1.addEmpleado(e2);
        em.getTransaction().begin();
        em.persist(d1);
        em.getTransaction().commit();
        emf.close();
        em.close();
    }

}
