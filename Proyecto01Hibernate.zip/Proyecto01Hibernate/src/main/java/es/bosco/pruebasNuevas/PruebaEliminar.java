package es.bosco.pruebasNuevas;

import es.bosco.modelo.Departamento;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PruebaEliminar {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //1. Obtener un manejador de entidades
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        Departamento d = em.find(Departamento.class, 1L);
        em.getTransaction().begin();
        em.remove(d);
        em.getTransaction().commit();
    }
}
