package es.bosco.modelo;

import jakarta.persistence.*;

@Entity
public class Direccion {
    @Id
    private Long idDirec;
    private String localidad;
    private String calle;
    private String cp;
    @OneToOne
    @JoinColumn(name = "ID_EMPLEADO", referencedColumnName = "ID_EMP")
    private Empleado empleado;
    public Direccion() {
    }
    public Direccion(Long idDirec, String localidad, String calle, String cp, Empleado empleado) {
        this.idDirec = idDirec;
        this.localidad = localidad;
        this.calle = calle;
        this.cp = cp;
        this.empleado = empleado;
    }

    public Long getIdDirec() {
        return idDirec;
    }

    public void setIdDirec(Long idD) {
        this.idDirec = idD;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    @Override
    public String toString() {
        return "Direccion{" +
                "idD=" + idDirec +
                ", localidad='" + localidad + '\'' +
                ", calle='" + calle + '\'' +
                ", cp='" + cp + '\'' +
                '}';
    }
}
