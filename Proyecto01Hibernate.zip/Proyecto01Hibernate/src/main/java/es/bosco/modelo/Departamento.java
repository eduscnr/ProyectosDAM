package es.bosco.modelo;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Departamento {
    @Id
    private Long idDep;
    @Column(unique = true)
    private String nombre;
    private String loc;
    @OneToMany (mappedBy = "departamento", cascade = CascadeType.ALL, orphanRemoval = true) //un departamento contiene o tiene muchos empleados
    private List<Empleado> empleados;

    public Departamento(Long idDep, String nombre, String loc) {
        this.idDep = idDep;
        this.nombre = nombre;
        this.loc = loc;
    }

    public Departamento() {

    }

    public Long getIdDep() {
        return idDep;
    }

    public void setIdDep(Long idDep) {
        this.idDep = idDep;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    @Override
    public String toString() {
        return "Departamento{" +
                "idDep=" + idDep +
                ", nombre='" + nombre + '\'' +
                ", loc='" + loc + '\'' +
                '}';
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }
}
