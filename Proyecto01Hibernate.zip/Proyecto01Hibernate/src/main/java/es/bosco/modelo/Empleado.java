package es.bosco.modelo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "EMPLEADOS")
public class Empleado {
    @Id
    @Column(name = "ID_EMP")
    private int idEmp;
    private String nombre;
    private float sueldo;
    private Date fechaNac;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_DEPT", foreignKey = @ForeignKey(name = "idDep"))
    private Departamento departamento;
    @OneToOne(mappedBy = "empleado", cascade = CascadeType.ALL, orphanRemoval = true)
    private Direccion direccion;

    public Empleado() {
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public Empleado(int idEmp, String nombre, float sueldo) {
        this.idEmp = idEmp;
        this.nombre = nombre;
        this.sueldo = sueldo;
    }

    public Empleado(int idEmp, String nombre, float sueldo, Departamento departamento) {
        this.idEmp = idEmp;
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.departamento = departamento;
    }

    public Empleado(int idEmp, String nombre, float sueldo, Date fechaNac, Departamento departamento) {
        this.idEmp = idEmp;
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.fechaNac = fechaNac;
        this.departamento = departamento;
    }
    public void addDireccion(Direccion d){
        direccion = d;
        d.setEmpleado(this);
    }

    public int getIdEmp() {
        return idEmp;
    }

    public void setIdEmp(int idEmp) {
        this.idEmp = idEmp;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getSueldo() {
        return sueldo;
    }

    public void setSueldo(float sueldo) {
        this.sueldo = sueldo;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public Date getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(Date fechaNac) {
        this.fechaNac = fechaNac;
    }

    public Empleado(int idEmp, String nombre, float sueldo, Date fechaNac) {
        this.idEmp = idEmp;
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.fechaNac = fechaNac;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "idEmp=" + idEmp +
                ", nombre='" + nombre + '\'' +
                ", sueldo=" + sueldo +
                ", departamento=" + departamento +
                '}';
    }

}
