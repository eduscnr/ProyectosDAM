package es.bosco.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "EMPLEADOS")
public class Empleado {
    @Id
    @Column(name = "ID_EMP")
    private int idEmp;
    private String nombre;
    private float sueldo;
    @ManyToOne
    @JoinColumn(name = "ID_DEPT", foreignKey = @ForeignKey(name = "idDep"))
    private Departamento departamento;

    public Empleado() {
    }

    public Empleado(int idEmp, String nombre, float sueldo, Departamento departamento) {
        this.idEmp = idEmp;
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.departamento = departamento;
    }

    public int getIdEmp() {
        return idEmp;
    }

    public void setIdEmp(int idEmp) {
        this.idEmp = idEmp;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getSueldo() {
        return sueldo;
    }

    public void setSueldo(float sueldo) {
        this.sueldo = sueldo;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "idEmp=" + idEmp +
                ", nombre='" + nombre + '\'' +
                ", sueldo=" + sueldo +
                ", departamento=" + departamento +
                '}';
    }

}
