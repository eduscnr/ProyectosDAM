package es.bosco.pruebas;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ProbarInsertarDepartamentoAyuda {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //Obtener un EntityManger
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        //Un departemento con dos empleados
        Departamento d1 = new Departamento(12L, "Química", "Toledo");
        Empleado e1 = new Empleado(42, "Monolo", 1500);
        Empleado e2 = new Empleado(52, "Juanita", 1500);
        d1.addEmpleado(e1);
        d1.addEmpleado(e2);
        //Persistimos solamente el departamento
        em.getTransaction().begin();
        em.persist(d1);
        em.getTransaction().commit();
        System.out.println("Funciono");
        em.close();
        emf.close();
    }
}
