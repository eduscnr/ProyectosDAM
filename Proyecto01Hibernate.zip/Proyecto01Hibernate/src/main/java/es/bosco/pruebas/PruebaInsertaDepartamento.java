package es.bosco.pruebas;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PruebaInsertaDepartamento {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //Obtener un EntityManger
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        //Un departemento con dos empleados
        Departamento d1 = new Departamento(10L, "Matemáticas", "Toledo");
        Empleado e1 = new Empleado(40, "Santiago", 1500);
        Empleado e2 = new Empleado(50, "Pepa", 1500);
        d1.getEmpleados().add(e1);
        e1.setDepartamento(d1);
        d1.getEmpleados().add(e2);
        e2.setDepartamento(d1);
        //Persistimos solamente el departamento
        em.getTransaction().begin();
        em.persist(d1);
        em.getTransaction().commit();
        System.out.println("Funciono");
        em.close();
        emf.close();

    }
}
