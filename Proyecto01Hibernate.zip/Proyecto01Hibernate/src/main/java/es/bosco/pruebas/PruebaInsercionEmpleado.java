package es.bosco.pruebas;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PruebaInsercionEmpleado {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //Obtener un EntityManger
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        //Un departemento con dos empleados
        Departamento d1 = new Departamento(11L, "Física", "Quero");
        Empleado e1 = new Empleado(41, "Juan", 1500);
        Empleado e2 = new Empleado(51, "Manoli", 1500);

        e1.setDepartamento(d1);
        e2.setDepartamento(d1);
        //Persistimos solamente el Empleados
        em.getTransaction().begin();
        em.persist(e1);
        em.persist(e2);
        em.getTransaction().commit();
        System.out.println("Funciono");
        em.close();
        emf.close();
    }
}
