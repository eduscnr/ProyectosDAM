package es.bosco.pruebas;

import es.bosco.modelo.Departamento;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProbarHibernate {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //Obtener una EntityManage
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        //Definir departamentos
        Departamento d1 = new Departamento(1L,"Informática", "Toledo");
        Departamento d2 = new Departamento(2L,"Comercio", "Toledo");
        Departamento d3 = new Departamento(3L,"Ventas", "Toledo");
        Departamento d4 = new Departamento(4L,"InformáticaNuevo", "Toledo");
        //Persistir departamentos
        em.getTransaction().begin();
        em.persist(d1);
        em.persist(d2);
        em.persist(d3);
        em.persist(d4);
        em.getTransaction().commit();
        em.flush();
        //Buscar un departamento por Id
        Departamento d = em.find(Departamento.class, 1L);
        String hql = "from Departamento d";
        List<Departamento> departamentoList = em.createQuery(hql).getResultList();
        departamentoList.forEach(dep ->{
            System.out.println(dep.getNombre());
        });
        System.out.println("nombre departamento");
        String hql1 = "from Departamento d where d.nombre = 'Informática'";
        Departamento depInf = (Departamento) em.createQuery(hql1).getSingleResult();
        System.out.println(depInf);

        System.out.println("Modificar departamento");
        Departamento depModiInf = null;
        try{
            em.getTransaction().begin();
            depModiInf = em.find(Departamento.class, 1L);
            depModiInf.setIdDep(2L);
            em.getTransaction().commit();
        }catch (Exception e){
            em.getTransaction().rollback();
        }
        //System.out.println(depModiInf.getIdDep());
        //Borrar Departamento
        //--------------------------------------------------------------------------//
        em.getTransaction().begin();
        em.remove(em.merge(d4));
        em.getTransaction().commit();
        String hql2 = "from Departamento d";
        List<Departamento> departamentoList1 = em.createQuery(hql2).getResultList();
        departamentoList1.forEach(dep ->{
            System.out.println(dep.getNombre());
        });
        //--------------------------------------------------------------------------//
        //cerrar
        em.close();
        emf.close();
    }
}
