package es.bosco.pruebas;

import es.bosco.modelo.Departamento;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ProbarBorrarDepartamentos {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //Obtener un EntityManger
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        //
        Departamento depBorrar = em.find(Departamento.class,1L);
        em.getTransaction().begin();
        em.remove(depBorrar);
        em.getTransaction().commit();

        em.close();
        emf.close();
    }
}
