package es.bosco.pruebas;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Prueba2 {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //1. Obtener un manejador de entidades
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        //2. Crear empleados asignados a su departamento
        //Departamento d1 = new Departamento(1L,"Informática", "Toledo");
        //Departamento d2 = new Departamento(2L,"Comercio", "Toledo");
        Departamento d1 = em.find(Departamento.class, 1L);
        Departamento d2 = em.find(Departamento.class, 2L);
        Empleado e1 = new Empleado(1, "Pepe", 1500, d1);
        Empleado e2 = new Empleado(2, "Ana", 1500, d1);
        Empleado e3 = new Empleado(3, "Juan", 1500, d2);
        //3.Persistir los empleados
        /*em.getTransaction().begin();
        em.persist(e1);
        em.persist(e2);
        em.persist(e3);
        em.getTransaction().commit();*/
        //4.Consultar
        String hql1 = "from Empleado e";
        List<Empleado> empleadoList = em.createQuery(hql1).getResultList();
        empleadoList.forEach(empl ->{
            System.out.println("El empleado " + empl.getNombre() + " pertenece al departamento " + empl.getDepartamento().getNombre());
        });
    }
}
