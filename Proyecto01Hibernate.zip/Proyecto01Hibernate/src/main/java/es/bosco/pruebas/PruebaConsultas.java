package es.bosco.pruebas;

import es.bosco.modelo.Departamento;
import es.bosco.modelo.Empleado;
import jakarta.persistence.*;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PruebaConsultas {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        //1. Obtener un manejador de entidades
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();


        String hql = "from Empleado e";
        List<Empleado> listaEmpleados = em.createQuery(hql).getResultList();
        listaEmpleados.forEach(e->{
            System.out.println(e.getNombre() + "---" + e.getDepartamento().getNombre());
        });

        //3. Consulta en nombre del depto y cuantso empleado tiene a su cargo
        String hql2 = "from Departamento d";
        List<Departamento> listaDepartamentos = em.createQuery(hql2).getResultList();
        listaDepartamentos.forEach(d ->{
            System.out.println(d.getNombre() + "---" + d.getEmpleados().size());
        });
        System.out.println("Departamento 1");
        String hqlDep = "from Departamento d";
        List<Departamento> listaDepartamentosTodos = em.createQuery(hqlDep).getResultList();
        listaDepartamentosTodos.forEach(d ->{
            if(d.getIdDep() == 1){
                System.out.println(d.getEmpleados());
            }
        });
        //6. Consulta los empleados de un departamento, por Nombre desde empleado (PARAMETRO)
        System.out.println("6. Consulta los empleados de un departamento, por Nombre del departamento (PARAMETRO)");
        Query query = em.createQuery("from Empleado e where e.departamento.nombre = :pNombreDep");
        query.setParameter("pNombreDep", "Informática");
        List<Empleado> listE = query.getResultList();
        listE.forEach(e->{
            System.out.println(e.getNombre() + "----" + e.getDepartamento().getNombre());
        });

        //7. Consulta los empleados de un departamento, por Nombre desde Departamento (PARAMETRO)
        System.out.println("7. Consulta los empleados de un departamento, por Nombre desde Departamento (PARAMETRO)");
        Query query1 = em.createQuery("from Departamento d where d.nombre = :pNombreDep");
        query1.setParameter("pNombreDep", "Informática");
        Departamento departamento = (Departamento) query1.getSingleResult();
        System.out.println(departamento);


    }
}
