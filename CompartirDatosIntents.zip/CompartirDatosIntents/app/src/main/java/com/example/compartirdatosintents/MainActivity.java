package com.example.compartirdatosintents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnWeb = findViewById(R.id.btnWeb);
        Button btnMapa = findViewById(R.id.btnMapa);
        Button btnEmail = findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);
        btnWeb.setOnClickListener(this);
        btnMapa.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent i=new Intent();
        Intent chooser=null;
        if(view.getId() == R.id.btnWeb){
            EditText edURL=(EditText)findViewById(R.id.edUrl);
            i.setAction(Intent.ACTION_VIEW);
            i.setData(Uri.parse(edURL.getText().toString()));
            chooser=i.createChooser(i,"Elige Navegador");
            startActivity(i);
            Toast.makeText(this.getApplicationContext(),"Acceso a web!",Toast.LENGTH_LONG).show();
        } else if (view.getId() == R.id.btnMapa) {
            EditText edLatitud=(EditText)findViewById(R.id.edLatitud);
            EditText edLongitud=(EditText)findViewById(R.id.edLongitud);
            i.setAction(Intent.ACTION_VIEW);
            i.setData(Uri.parse("geo:"+edLatitud.getText().toString()+" ,"+edLongitud.getText().toString()));
            chooser=i.createChooser(i,"Lanzar Mapas");
            startActivity(i);
            Toast.makeText(this.getApplicationContext(),"Acceso a mapas!",Toast.LENGTH_LONG).show();
        } else if (view.getId()==R.id.btnEmail) {
            EditText edEmail=(EditText)findViewById(R.id.edEmail);
            i.setAction(Intent.ACTION_SEND);
            i.setData(Uri.parse("mailto:"));
            String para[]={edEmail.getText().toString(),"otrocontacto@gmail.com"};
            i.putExtra(Intent.EXTRA_EMAIL,para);
            i.putExtra(Intent.EXTRA_SUBJECT,"Saludos desde Android");
            i.putExtra(Intent.EXTRA_TEXT,"Hola!!. ¿Qué tal?. Este es nuestro primer email");
            i.setType("message/rfc822");
            chooser=i.createChooser(i,"Enviar Email");
            startActivity(i);
            Toast.makeText(this.getApplicationContext(),"Envía el email!!",Toast.LENGTH_LONG).show();
        }
    }
}