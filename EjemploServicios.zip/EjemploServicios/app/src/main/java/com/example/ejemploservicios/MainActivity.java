package com.example.ejemploservicios;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /* Arranca el servicio Wireless Tester */
    public void Arrancar(View v){
        startService(new Intent(getBaseContext(), WirelessTester.class));
    }
    /* Detiene el servicio Wireless Tester */
    public void Detener(View v){
        stopService(new Intent(getBaseContext(), WirelessTester.class));
    }
}

