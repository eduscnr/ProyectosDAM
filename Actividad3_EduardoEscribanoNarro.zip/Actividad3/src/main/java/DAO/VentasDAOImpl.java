package DAO;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.PersistenceException;
import modelo.*;

import java.util.Date;
import java.util.List;

public class VentasDAOImpl implements VentasDAO{
    private EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;

    public VentasDAOImpl(String up) {
        entityManagerFactory = Persistence.createEntityManagerFactory(up);
        entityManager = entityManagerFactory.createEntityManager();
    }

    @Override
    public boolean insertarVentas(Long idVentas, Usuario usuario, Categoria categoria, List<Producto> productos) {
        try {
            entityManager.getTransaction().begin();

            if (usuario.getIdUsuario() != null) {
                usuario = entityManager.find(Usuario.class, usuario.getIdUsuario());
            }

            if (categoria.getIdCategoria() != null) {
                Categoria existingCategoria = entityManager.find(Categoria.class, categoria.getIdCategoria());
                if (existingCategoria != null) {
                    categoria = existingCategoria;
                }
            }


            Ventas venta = new Ventas(idVentas, usuario, new Date());
            usuario.getVentasUsu().add(venta);

            for (int i = 0; i < productos.size(); i++) {
                Producto producto = productos.get(i);
                    producto = entityManager.find(Producto.class, producto.getIdProducto());
                    if(producto == null){
                        producto = productos.get(i);
                        producto.setCategoria(categoria);
                    }

                DetallesVentas detalle = new DetallesVentas(new DetalleVentaId(venta, i + 1), producto, producto.getPrecio(), 1, 0);
                venta.getDetallesVentasList().add(detalle);
            }
            venta.setCliente(usuario);
            entityManager.persist(venta);
            entityManager.getTransaction().commit();
            return true;
        } catch (PersistenceException e) {
            entityManager.getTransaction().rollback();
            e.printStackTrace();
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean eliminarVenta(Long idVenta) {
        try{
            entityManager.getTransaction().begin();
            Ventas venta = entityManager.find(Ventas.class, idVenta);
            entityManager.remove(venta);
            entityManager.getTransaction().commit();
            return true;
        }catch (PersistenceException e){
            entityManager.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void mostrarListado(Long idUsuario) {
        double total = 0;
        try{
            Usuario cliUsuario = entityManager.find(Usuario.class, idUsuario);
            for (Ventas v: cliUsuario.getVentasUsu()){
                System.out.println("Cabecera: "+v.getFecha() + "-------" + v.getCliente().getNombre());
                for (DetallesVentas dv : v.getDetallesVentasList()){
                    double importe = (dv.getCantidad()*dv.getPvp());
                    double descuento = (importe * dv.getPctDescuento()) /100;
                    total += importe - descuento;
                    System.out.println("Cuerpo: " + dv.getCantidad() + "-----" + dv.getPvp() + "-------" + dv.getCodigoproducto().getNombre() + "------" + importe + "-------" + descuento);
                }
                System.out.println("Pie: " + "Total: " + total);
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void insertarCategoria(Categoria c) {
        try{
            entityManager.getTransaction().begin();
            entityManager.persist(c);
            entityManager.getTransaction().commit();
        }catch (Exception e){
            entityManager.getTransaction().rollback();
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void insertarProductoACategoria(Long idCategoria, List<Producto> productos) {
        try{
            Categoria c =  entityManager.find(Categoria.class, idCategoria);
            if(c != null){
                entityManager.getTransaction().begin();
                System.out.println("Entro");
                for (Producto p : productos){
                    p.setCategoria(c);
                    entityManager.merge(p);
                }
                entityManager.getTransaction().commit();
            }
        }catch (Exception e){
            entityManager.getTransaction().rollback();
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void obtnerListadoProducto(Long idCategoria) {
        try{
            Categoria c = entityManager.find(Categoria.class, idCategoria);
            for (Producto p : c.getProductos()){
                System.out.println(p);
            }
        }catch (Exception e){
            entityManager.getTransaction().rollback();
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void obtenerListadoCategoria() {
        try{
            entityManager.getTransaction().begin();
            List<Categoria> categorias = entityManager.createQuery("from Categoria c").getResultList();
            for (Categoria c : categorias){
                System.out.println(c.getNombre());
                for (Producto p : c.getProductos()){
                    System.out.println(p.getNombre() + "----" + p.getPrecio());
                }
                System.out.println("--------");
            }
            entityManager.getTransaction().commit();
        }catch (Exception e){
            entityManager.getTransaction().rollback();
            System.out.println(e.getMessage());
        }
    }

}
