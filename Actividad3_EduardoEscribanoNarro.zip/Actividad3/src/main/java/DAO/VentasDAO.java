package DAO;

import modelo.Categoria;
import modelo.Producto;
import modelo.Usuario;

import java.util.List;

public interface VentasDAO {
    public boolean insertarVentas(Long idVentas,Usuario usuario, Categoria categoria, List<Producto> productos);
    public boolean eliminarVenta(Long idVenta);
    public void mostrarListado(Long idUsuario);
    public void insertarCategoria(Categoria c);
    public void insertarProductoACategoria(Long idCategoria, List<Producto> productos);
    public void obtnerListadoProducto(Long idCategoria);
    public void obtenerListadoCategoria();
}
