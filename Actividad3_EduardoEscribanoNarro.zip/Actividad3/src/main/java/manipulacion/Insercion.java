package manipulacion;

import DAO.VentasDAO;
import DAO.VentasDAOImpl;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import modelo.Categoria;
import modelo.Producto;
import modelo.Usuario;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Descomenta el código y usa los metodos que quieres, debes de crear el usuario Eduardo2 en oracle y en create para que se cree las tablas
 * o tambien lo puedes dejar en update porque tambien se crearian.
 */
public class Insercion {
    public static void main(String[] args) {
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("upEduardo");
        EntityManager em = emf.createEntityManager();
        /*em.getTransaction().begin();
        System.out.println("Operacion Realizada");
        em.getTransaction().commit();
        emf.close();
        em.close();*/
        /*Usuario cliente = new Usuario(1L, "Escribano", "Eduardo","Villafranca", "prueba", "educhelero13@gmail.com", "1234");
        Categoria categoria = new Categoria(2L, "Electrónica", "imagen_electronica.jpg");*/
        /*List<Producto> productos = Arrays.asList(
                new Producto(50L, "prueba1", "Descripción1", 100.0f, "imagen_producto1.jpg"),
                new Producto(80L, "prueba2", "Descripción2", 150.0f, "imagen_producto2.jpg"),
                new Producto(90L, "prueba3", "Descripción3", 200.0f, "imagen_producto3.jpg")
        );*/
        VentasDAO ventasDAO = new VentasDAOImpl("upEduardo");
        //ventasDAO.obtnerListadoProducto(12L);
        //ventasDAO.insertarProductoACategoria(12L, productos);
        //ventasDAO.mostrarListado(1L);
        //ventasDAO.insertarCategoria(new Categoria(12L, "Prueba", "Prueba"));
        //ventasDAO.insertarVentas(4L, cliente, categoria, productos);
        //ventasDAO.eliminarVenta(1L);
        //ventasDAO.obtenerListadoCategoria();

    }
}
