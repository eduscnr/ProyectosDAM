package modelo;

import jakarta.persistence.*;

@Entity
public class DetallesVentas {
    @EmbeddedId
    private DetalleVentaId detalleVentaId;
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "ID_PROD")
    private Producto codigoproducto;
    private double pvp;
    private int cantidad;
    private int pctDescuento;

    public DetallesVentas(DetalleVentaId detalleVentaId, Producto codigoproducto, double pvp, int cantidad, int pctDescuento) {
        this.detalleVentaId = detalleVentaId;
        this.codigoproducto = codigoproducto;
        this.pvp = pvp;
        this.cantidad = cantidad;
        this.pctDescuento = pctDescuento;
    }

    public DetallesVentas() {
    }

    public DetalleVentaId getDetalleVentaId() {
        return detalleVentaId;
    }

    public void setDetalleVentaId(DetalleVentaId detalleVentaId) {
        this.detalleVentaId = detalleVentaId;
    }

    public Producto getCodigoproducto() {
        return codigoproducto;
    }

    public void setCodigoproducto(Producto codigoproducto) {
        this.codigoproducto = codigoproducto;
    }

    public double getPvp() {
        return pvp;
    }

    public void setPvp(double pvp) {
        this.pvp = pvp;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPctDescuento() {
        return pctDescuento;
    }

    public void setPctDescuento(int pctDescuento) {
        this.pctDescuento = pctDescuento;
    }


    @Override
    public String toString() {
        return "DetallesVentas{" +
                "detalleVentaId=" + detalleVentaId +
                ", codigoproducto=" + codigoproducto +
                ", pvp=" + pvp +
                ", cantidad=" + cantidad +
                ", pctDescuento=" + pctDescuento +
                '}';
    }
}
