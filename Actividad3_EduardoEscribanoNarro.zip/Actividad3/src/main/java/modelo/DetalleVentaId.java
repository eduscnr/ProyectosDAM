package modelo;

import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.io.Serializable;

@Embeddable
public class DetalleVentaId implements Serializable {
    @ManyToOne
    @JoinColumn(name = "ID_VENTAS")
    private Ventas idVentas;
    private int numLinea;

    public DetalleVentaId(Ventas idVentas, int numLinea) {
        this.idVentas = idVentas;
        this.numLinea = numLinea;
    }

    public DetalleVentaId() {
    }

    public Ventas getIdVentas() {
        return idVentas;
    }

    public void setIdVentas(Ventas idVentas) {
        this.idVentas = idVentas;
    }

    public int getNumLinea() {
        return numLinea;
    }

    public void setNumLinea(int numLinea) {
        this.numLinea = numLinea;
    }

    @Override
    public String toString() {
        return "DetalleVentaId{" +
                "idVentas=" + idVentas +
                ", numLinea=" + numLinea +
                '}';
    }
}
