package modelo;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Usuario {
    @Id
    private Long idUsuario;
    private String apellidos;
    private String nombre;
    private String localidad;
    private String perfil;
    private String correo;
    private String claveusu;
    @OneToMany (mappedBy = "cliente", cascade = CascadeType.ALL)
    private List<Ventas> ventasUsu = new ArrayList<>();

    public Usuario() {
    }

    public Usuario(Long idUsuario, String apellidos, String nombre, String localidad, String perfil, String correo, String claveusu) {
        this.idUsuario = idUsuario;
        this.apellidos = apellidos;
        this.nombre = nombre;
        this.localidad = localidad;
        this.perfil = perfil;
        this.correo = correo;
        this.claveusu = claveusu;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClaveusu() {
        return claveusu;
    }

    public void setClaveusu(String claveusu) {
        this.claveusu = claveusu;
    }

    public List<Ventas> getVentasUsu() {
        return ventasUsu;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "idUsuario=" + idUsuario +
                ", apellidos='" + apellidos + '\'' +
                ", nombre='" + nombre + '\'' +
                ", localidad='" + localidad + '\'' +
                ", perfil='" + perfil + '\'' +
                ", correo='" + correo + '\'' +
                ", claveusu='" + claveusu + '\'' +
                '}';
    }
}
