package modelo;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity

public class Ventas {
    @Id
    private Long idVenta;
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "ID_CLIE")
    private Usuario cliente;
    private Date fecha;
    @OneToMany(mappedBy = "detalleVentaId.idVentas", cascade = CascadeType.ALL)
    private List<DetallesVentas> detallesVentasList = new ArrayList<>();

    public Ventas() {
    }

    public Ventas(Long idVenta, Usuario cliente, Date fecha) {
        this.idVenta = idVenta;
        this.cliente = cliente;
        this.fecha = fecha;
    }

    public Long getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(Long idVenta) {
        this.idVenta = idVenta;
    }

    public Usuario getCliente() {
        return cliente;
    }

    public void setCliente(Usuario cliente) {
        this.cliente = cliente;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public List<DetallesVentas> getDetallesVentasList() {
        return detallesVentasList;
    }


    @Override
    public String toString() {
        return "Ventas{" +
                "idVenta=" + idVenta +
                ", cliente=" + cliente +
                ", fecha=" + fecha +
                '}';
    }
}
