/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacionsistemasreservateatro;

import java.util.Random;

/**
 *
 * @author Eduardo
 */
public class Cliente extends Thread{
    private String nombre;
    private Teatro t;
    private int intentos;
    private Random generado;
    private int columna;
    private int fila;

    public Cliente(String nombre, Teatro t, int intentos) {
        super(nombre);
        this.nombre = nombre;
        this.t = t;
        this.intentos = intentos;
        generado = new Random();
    }
    @Override
    public void run(){
        for (int i = 1; i <= intentos; i++) {
            if(t.asignarAsiento(nombre, generarFila(), generarColumna())){
                return;
            }
        }
        System.out.println("Lo ha intentado pero no ha podido reservar :() ");
    }
    public int generarColumna(){
        return columna = generado.nextInt(3);
    }
    public int generarFila(){
        return fila = generado.nextInt(3);
    }
}
