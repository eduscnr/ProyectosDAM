/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacionsistemasreservateatro;

/**
 *
 * @author Eduardo
 */
public class Teatro {
    private boolean[][]asientos;
    private int numerosAsientos;

    public Teatro(int numerosAsientos) {
        this.numerosAsientos = numerosAsientos;
        asientos = new boolean[numerosAsientos][numerosAsientos];
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                asientos[i][j] = true;
            }
        }
    }
    
    public synchronized boolean asignarAsiento(String nombre, int fila, int columna){
        if(asientos[fila][columna]){
            System.out.println("El cliente: " + nombre + " se ha sentado en la fila: " + fila + " y columna: " + columna + " RESERVADO");
            asientos[fila][columna] = false;
            return true;
        }
        System.out.println("El cliente: " + nombre + " se ha querido sentar en la fila: " + fila + " y columna: " + columna + " PERO ESTABA RESERVADO");
        return false;
    }
    
}
