/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simulacionsistemasreservateatro;

/**
 *
 * @author Eduardo
 */
public class SimulacionSistemasReservaTeatro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final int NUM_CLIENTE = 25;
        final int NUM_ASIENTOS = 3;
        Cliente clientes[] = new Cliente[NUM_CLIENTE];
        Teatro t = new Teatro(NUM_ASIENTOS);
        for (int i = 0; i < NUM_CLIENTE; i++) {
            clientes[i] = new Cliente("Cliente " + i, t, 3);
            clientes[i].start();
        }
    }
    
}
