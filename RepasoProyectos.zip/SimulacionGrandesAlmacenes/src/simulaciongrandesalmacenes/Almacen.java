/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulaciongrandesalmacenes;

/**
 *
 * @author Eduardo
 */
public class Almacen {
    private int numProducto;

    public Almacen(int numProducto) {
        this.numProducto = numProducto;
    }
    public synchronized boolean cogerProducto(){
        if(numProducto >0){
            numProducto--;
            return true;
        }
        return false;
    }
    
}
