/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simulaciongrandesalmacenes;

/**
 *
 * @author Eduardo
 */
public class SimulacionGrandesAlmacenes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final int NUM_CLIENTES = 300;
        final int NUM_PRODUCTOS = 100;
        Cliente []clientes = new Cliente[NUM_CLIENTES];
        Almacen a = new Almacen(NUM_PRODUCTOS);
        Puerta p = new Puerta();
        for(int i =0;i<NUM_CLIENTES;i++){
            clientes[i] = new Cliente(a, p, "Cliente " + i);
            clientes[i].start();
        }
        
    }
    
}
