/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulaciongrandesalmacenes;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Eduardo
 */
public class Cliente extends Thread{
    private Almacen a;
    private Puerta p;
    private String nombre;
    private Random r;
    private int intentos = 10;

    public Cliente(Almacen a, Puerta p, String nombre) {
        super(nombre);
        this.a = a;
        this.p = p;
        this.nombre = nombre;
        r = new Random();
    }

    @Override
    public void run() {
       for(int i =0;i<=intentos;i++){
           if(!p.puertaOcupada()){
               if(p.intentarEntrar()){
                   esperar();
                   p.liberarPuerta();
                   if(a.cogerProducto()){
                       System.out.println("El cliente: " + nombre + " a cogido un producto");
                       return;
                   }else{
                       System.out.println("El cliente: " + nombre + " cruzó pero no habia productos");
                       return;
                   }
               }
           }else{
               esperar();
           }
       }
        System.out.println("El cliente: " + nombre + " intento entrar pero no puedo");
    }

    public void esperar(){
        try {
            int tiempoAlazar = r.nextInt(100);
            sleep(tiempoAlazar);
        } catch (InterruptedException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
