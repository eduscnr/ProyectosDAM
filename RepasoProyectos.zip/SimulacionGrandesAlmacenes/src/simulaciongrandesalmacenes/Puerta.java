/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulaciongrandesalmacenes;

/**
 *
 * @author Eduardo
 */
public class Puerta {
    private boolean ocupada;

    public Puerta() {
        ocupada = false;
    }
    public boolean puertaOcupada(){
        return ocupada;
    }
    public synchronized boolean intentarEntrar(){
        if(ocupada){
            ocupada = false;
            return false;
        }
        ocupada = true;
        return true;
    }
    public synchronized void liberarPuerta(){
        ocupada = false;
    }
    
}
