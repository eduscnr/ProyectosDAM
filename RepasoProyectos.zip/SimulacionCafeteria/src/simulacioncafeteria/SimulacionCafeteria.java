/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simulacioncafeteria;

/**
 *
 * @author Eduardo
 */
public class SimulacionCafeteria {
    private static final int NUMERO_BARISTAS = 2;
    private static final int NUMERO_CLIENTES = 3;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cafeteria cafeteria = new Cafeteria();
        for (int i = 1; i <= NUMERO_CLIENTES; i++) {
            Cliente cliente = new Cliente(cafeteria, "Cliente " + i);
            cliente.start();
        }
        for (int i = 1; i <= NUMERO_BARISTAS; i++) {
            Barista barista = new Barista(cafeteria, "Barista " + i);
            barista.start();
        }

    }
    
}
