/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacioncafeteria;

/**
 *
 * @author Eduardo
 */
public class Cafeteria{
    private boolean preparado = false;
    private boolean entregado = false;
    public Cafeteria() {
    }
    public synchronized void prepararCafe(String nombreBarista) throws InterruptedException{
        while(entregado){
            wait();
        }
        System.out.println(nombreBarista + " está preparando café.");
        Thread.sleep(2000);  // Simulación de tiempo de preparación
        System.out.println(nombreBarista + " ha preparado el café para");
        preparado = true;
        entregado = true;
        notifyAll();
    }
    public synchronized void entregarCafe(String nombreCliente) throws InterruptedException{
        while(!preparado){
            wait();
        }
        System.out.println("le ha entregado el cafe a " + nombreCliente);
        preparado = false;
        entregado = false;
        notifyAll();
    }
    
}
