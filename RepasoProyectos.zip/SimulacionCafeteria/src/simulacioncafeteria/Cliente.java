/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacioncafeteria;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Eduardo
 */
public class Cliente extends Thread{
    private Cafeteria c;
    private String nombre;

    public Cliente(Cafeteria c, String nombre) {
        super(nombre);
        this.c = c;
        this.nombre = nombre;
    }
    @Override
    public void run(){
        while(true){
            try {
                c.entregarCafe(nombre);
            } catch (InterruptedException ex) {
                Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
