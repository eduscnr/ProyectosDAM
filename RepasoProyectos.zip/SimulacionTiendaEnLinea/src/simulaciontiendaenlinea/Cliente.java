/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulaciontiendaenlinea;

import java.util.Random;

/**
 *
 * @author Eduardo
 */
public class Cliente extends Thread{
    private String nombre;
    private int dineroTotal;
    private Producto producto;
    private Random generarCantidad = new Random();
    private int cantidadPedido;

    public Cliente(String nombre, int dineroTotal, Producto producto) {
        super(nombre);
        this.nombre = nombre;
        this.dineroTotal = dineroTotal;
        this.producto = producto;
        cantidadPedido = generarCantidad.nextInt(15)+1;
    }
    @Override
    public void run(){
        int dineroARestar = producto.comprarProducto(nombre, dineroTotal, cantidadPedido);
        dineroTotal -= dineroARestar;
    }
    
}
