/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulaciontiendaenlinea;

/**
 *
 * @author Eduardo
 */
public class Producto {
    private String nombre;
    private int precio;
    private int cantidad;

    public Producto(String nombre, int precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
    
    public synchronized int comprarProducto(String nombreCliente, int dineroCliente, int cantidadPedida){
        int restarDinero = 0;
        if(dineroCliente >= precio*cantidadPedida && cantidad >= cantidadPedida){
            cantidad -= cantidadPedida;
            restarDinero = dineroCliente - precio*cantidadPedida;
            System.out.println("El cliente: " + nombreCliente + " ha comprado el producto: " + nombre + " esta cantidad: " + cantidadPedida + " y le ha sobrado: " + restarDinero);
        }else{
            if(cantidad < cantidadPedida){
                System.out.println("El cliente: " + nombreCliente + " ha pedido el producto: " + nombre + " una cantidad: " + cantidadPedida + " que no hay del producto: " + cantidad);
            }else{
                System.out.println("El cliente: " + nombreCliente + " no tiene dinero para comprar, se queria gasta" + cantidadPedida*precio +" de este producto " +  " nombre producto: " + nombre  + " el cliente tiene: " + dineroCliente);
            }
        }
        return restarDinero;
    }

    @Override
    public String toString() {
        return "Producto{" + "nombre=" + nombre + ", precio=" + precio + ", cantidad=" + cantidad + '}';
    }
    
}
