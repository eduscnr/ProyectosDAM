/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simulaciontiendaenlinea;

import java.util.Random;

/**
 *
 * @author Eduardo
 */
public class SimulacionTiendaEnLinea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final int NUM_CLIENTES = 10;
        Random r = new Random();
        Producto []productos = {
            new Producto("Suavizante", 15, 20),
            new Producto("Lejia", 25, 10),
            new Producto("Limpia cristales", 50, 15)
        };
        Cliente clientes[] = new Cliente[NUM_CLIENTES];
        for (int i = 0; i < NUM_CLIENTES; i++) {
            clientes[i] = new Cliente("Cliente "+ i, 150, productos[r.nextInt(3)]);
            clientes[i].start();
        }
    }
    
}
