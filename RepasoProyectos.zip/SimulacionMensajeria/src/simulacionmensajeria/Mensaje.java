/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacionmensajeria;

import java.util.Random;

/**
 *
 * @author Eduardo
 */
public class Mensaje {
    private String[] mensaje;
    private Random r = new Random();
    
    public Mensaje() {
        mensaje = new String[]{
            "¡Hola que tal estas!",
            "¿Como te va la vida?",
            "Hellooooo",
            "Me ha llamado tu madre",
            "Pero buenoooooo",
            "Soy un NPC",
            "Haz la comida por favor",
            "Estoy cansado jefe",
            "La vida",
        };
    }
    public synchronized void enviarMensje(Usuario remitente) throws InterruptedException{
        String elegirMensaje = mensaje[r.nextInt(mensaje.length)];
        System.out.println("Se ha enviado este mensaje: " + elegirMensaje + " al usuario: " + remitente.getName());
        Thread.sleep(1500);
    }
    
}
