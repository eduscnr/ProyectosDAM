/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simulacionmensajeria;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Eduardo
 */
public class Usuario extends Thread{
    private String nombre;
    private Mensaje m;

    public Usuario(String nombre, Mensaje m) {
        super(nombre);
        this.nombre = nombre;
        this.m = m;
    }
    @Override
    public void run(){        
            try {
                m.enviarMensje(this);
            } catch (InterruptedException ex) {
                Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    public String getNombre() {
        return nombre;
    }
    
    
}
