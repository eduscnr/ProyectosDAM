package org.example;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OpenLibraryScraper {

    public static void main(String[] args) {
        String baseUrl = "https://openlibrary.org/search?q=language%3Aspa";
        int currentPage = 7457;
        try {
            while (true) {
                String url = baseUrl + "&page=" + currentPage;

                // Conectar y obtener el HTML de la página
                Document document = Jsoup.connect(url)
                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3")
                        .get();

                // Encontrar elementos que contienen la información que necesitas
                Elements titles = document.select(".booktitle a");
                Elements bookCovers = document.select(".bookcover a img");

                // Verificar si hay resultados en la página actual
                if (titles.isEmpty()) {
                    break; // Salir del bucle si no hay más resultados
                }

                // Iterar sobre los resultados e imprimir títulos y portadas (si están disponibles)
                for (int i = 0; i < titles.size(); i++) {
                    String title = titles.get(i).text();
                    String coverUrl = bookCovers.get(i).attr("src");
                    if(coverUrl.equals("/images/icons/avatar_book-sm.png")){
                       coverUrl = "";
                    }
                    insertar(title, coverUrl);
                    //Aquí iba un if
                }

                currentPage++; // Avanzar a la siguiente página
                System.out.println("Estoy en la página: " + currentPage);
                // Agregar una pausa de algunos segundos entre las solicitudes
                Thread.sleep(2000); // Pausa de 2 segundos, ajusta según sea necesario
                System.out.println("Estoy durmiendo");

            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static void insertar(String title, String url){
        JDBC sqlite = new JDBC();
        String query = "INSERT INTO Libros (titulo, url) values (?, ?)";
        try {
            PreparedStatement preparedStatement = sqlite.getConnection().prepareStatement(query);
            preparedStatement.setString(1, title);
            preparedStatement.setString(2, url);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                sqlite.getConnection().close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
                    /*if (!coverUrl.equals("/images/icons/avatar_book-sm.png")) {
                        // Imprimir título y portada si el libro tiene una portada
                        System.out.println("Título: " + title);
                        System.out.println("Portada: " + coverUrl);
                    } else {
                        // Imprimir solo el título si el libro no tiene portada
                        System.out.println("Título: " + title);
                    }*/