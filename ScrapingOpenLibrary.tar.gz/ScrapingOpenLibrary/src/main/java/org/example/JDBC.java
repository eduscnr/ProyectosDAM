package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBC {
    Connection connection;

    public JDBC() {
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:Libros.db");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Connection getConnection() {
        return connection;
    }
}
