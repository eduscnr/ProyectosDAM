package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        String apiKey = "AIzaSyBEXPx3sc1MWV9BAUeURH76s-kRzgh7prc";
        int maxResults = 40;
        int startIndex = 0;
        boolean salir = false;
        while (!salir) {
            String urlString = "https://www.googleapis.com/books/v1/volumes?q=a&maxResults=" +
                    maxResults + "&startIndex=" + startIndex + "&langRestrict=es&key=" + apiKey;

            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(connection.getInputStream());

                // Procesar la respuesta JSON
                Iterator<JsonNode> items = jsonNode.path("items").elements();
                while (items.hasNext()) {
                    JsonNode item = items.next();
                    String title = item.path("volumeInfo").path("title").asText();
                    String description = item.path("volumeInfo").path("description").asText();

                    // La URL de la foto puede tener múltiples imágenes de diferentes tamaños, aquí se obtiene la primera
                    String photoUrl = item.path("volumeInfo").path("imageLinks").path("thumbnail").asText();

                    // Imprimir o hacer lo que necesites con la información
                    System.out.println("Title: " + title);
                    System.out.println("Description: " + description);
                    System.out.println("Photo URL: " + photoUrl);
                    System.out.println("--------");
                }

                // Incrementar startIndex para la próxima página

                startIndex++;

                // Salir del bucle si no hay más resultados
                /*if (!jsonNode.has("items") || jsonNode.path("items").size() < maxResults) {
                    break;
                }*/
                salir = true;
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
        }
    }
    }