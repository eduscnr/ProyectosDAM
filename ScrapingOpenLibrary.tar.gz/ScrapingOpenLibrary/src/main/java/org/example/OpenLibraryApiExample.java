package org.example;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OpenLibraryApiExample {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static void main(String[] args) {
        String searchTerm = "language:spa";
        int page = 1;
        int libros = 1;

        try {
            while (true) {
                // Construir la URL de la búsqueda con el parámetro de paginación
                String apiUrl = "https://openlibrary.org/search.json?q=" + searchTerm + "&page=" + page;

                // Realizar la solicitud HTTP
                String jsonResponse = sendHttpRequest(apiUrl);

                // Procesar la respuesta JSON con Jackson
                JsonNode jsonNode = objectMapper.readTree(jsonResponse);
                JsonNode docsArray = jsonNode.get("docs");

                // Iterar sobre los resultados
                for (JsonNode book : docsArray) {
                    // Obtener los campos deseados con Jackson
                    String title = book.path("title").asText();

                    String author = book.path("author_name").isArray()
                            ? book.path("author_name").get(0).asText("Unknown Author")
                            : "Unknown Author";

                    // Obtener la URL de la imagen
                    String coverUrl = "https://covers.openlibrary.org/b/id/" + book.path("cover_i").asText() + "-L.jpg";

                    // Obtener la descripción
                    String description = getDescription(book);

                    // Obtener la categoría
                    String category = book.path("subject").isArray()
                            ? book.path("subject").get(0).asText("No category")
                            : "No category";

                    // Obtener ISBN-10
                    String isbn10 = book.path("isbn").isArray()
                            ? book.path("isbn").get(0).asText("No ISBN-10")
                            : "No ISBN-10";

                    // Imprimir la información
                    System.out.println("Title: " + title);
                    System.out.println("Author: " + author);
                    System.out.println("Cover URL: " + coverUrl);
                    System.out.println("Description: " + description);
                    System.out.println("Category: " + category);
                    System.out.println("ISBN-10: " + isbn10);
                    System.out.println("---------------");
                }

                // Ir a la siguiente página
                page++;
                System.out.println(libros);
                libros++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static String sendHttpRequest(String apiUrl) throws Exception {
        StringBuilder result = new StringBuilder();
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("GET");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        }

        return result.toString();
    }
    private static String getDescription(JsonNode book) throws Exception {
        // Obtener todas las claves del nodo "book"
        Iterator<String> fieldNames = book.fieldNames();
        String prueba = "https://openlibrary.org";

        // Iterar sobre las claves para encontrar un campo que contenga texto
        while (fieldNames.hasNext()) {
            String fieldName = fieldNames.next();
            JsonNode fieldValue = book.path(fieldName);

            // Verificar si el valor de la clave actual es un texto (posible descripción)
            if (fieldValue.isTextual()) {
                String pruebaMostrar = sendHttpRequest(prueba+fieldValue.asText()+".json");
                System.out.println(prueba+fieldValue.asText()+".json");
                JsonNode jsonNode = objectMapper.readTree(pruebaMostrar);
                JsonNode description = jsonNode.get("description");
                if(description == null){
                    return "";
                }
                return description.asText();
            }
        }

        // Devolver una cadena vacía si no se encuentra ninguna descripción
        return "";
    }





}

